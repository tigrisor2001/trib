(() => {
    const $ = (selector) => document.querySelector(selector);
    const $$ = (selector) => Array.from(document.querySelectorAll(selector));
    const params = new URLSearchParams(window.location.search);

    const symbolFiles = {
        scatter: 'coroana.webp',
        om: '7.webp',
        faraon: 'pepene.webp',
        scarabeu: 'strugure.webp',
        buburuza: 'clopotel.webp',
        a: 'portocala.webp',
        k: 'pruna.webp',
        q: 'lamaie.webp',
        j: 'cireasa.webp',
        dollar: 'dolar.webp',
        iq_i: 'i.webp',
        iq_q: 'q.webp',
        iq_w: 'w.webp',
        iq_n: 'n.webp'
    };

    const paytableLabels = {
        scatter: 'Coroana Wild',
        dollar: 'Dolar',
        om: '7',
        faraon: 'Pepene',
        scarabeu: 'Strugure',
        buburuza: 'Clopotel',
        a: 'Portocala',
        k: 'Pruna',
        q: 'Lamaie',
        j: 'Ciresa',
        iq_i: 'I',
        iq_q: 'Q',
        iq_w: 'W',
        iq_n: 'N',
        iqwin: 'IQWIN'
    };

    const IQWIN_LINE_SEQUENCE = ['iq_i', 'iq_q', 'iq_w', 'iq_i', 'iq_n'];
    const IQWIN_LINE_PAY = 1000;
    const IQWIN_SYMBOLS = new Set(['iq_i', 'iq_q', 'iq_w', 'iq_n']);
    const IQWIN_REVEAL_CLASS = {
        iq_i: 'is-iqwin-i',
        iq_q: 'is-iqwin-q',
        iq_w: 'is-iqwin-w',
        iq_n: 'is-iqwin-n'
    };

    const symbolKeys = Object.keys(symbolFiles);

        const paytable = {
        scatter: { 5: 80, 4: 8, 3: 0.8 },
        om: { 5: 500, 4: 100, 3: 10 },
        faraon: { 5: 100, 4: 20, 3: 5 },
        scarabeu: { 5: 100, 4: 20, 3: 5 },
        buburuza: { 5: 50, 4: 15, 3: 3 },
        a: { 5: 25, 4: 4, 3: 1 },
        k: { 5: 25, 4: 4, 3: 1 },
        q: { 5: 25, 4: 4, 3: 1 },
        j: { 5: 25, 4: 4, 3: 1 }
    };

    const paytableOrder = ['om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar'];

    const DOLLAR_TOTAL_BET_PAY = { 3: 2, 4: 20, 5: 100 };

    const paylines = [
        [1, 1, 1, 1, 1],
        [0, 0, 0, 0, 0],
        [2, 2, 2, 2, 2],
        [0, 1, 2, 1, 0],
        [2, 1, 0, 1, 2],
        [0, 0, 1, 2, 2],
        [2, 2, 1, 0, 0],
        [1, 0, 0, 0, 1],
        [1, 2, 2, 2, 1],
        [0, 1, 1, 1, 0]
    ];

    const lineColors = [
        { main: '#0f7a24', soft: 'rgba(15, 122, 36, 0.42)', glow: 'rgba(20, 96, 36, 0.56)', core: '#14532d' },
        { main: '#9a6b05', soft: 'rgba(154, 107, 5, 0.42)', glow: 'rgba(120, 77, 8, 0.56)', core: '#713f12' },
        { main: '#0c5a8f', soft: 'rgba(12, 90, 143, 0.42)', glow: 'rgba(7, 71, 118, 0.56)', core: '#075985' },
        { main: '#9f1239', soft: 'rgba(159, 18, 57, 0.42)', glow: 'rgba(136, 19, 55, 0.56)', core: '#881337' },
        { main: '#5b21b6', soft: 'rgba(91, 33, 182, 0.42)', glow: 'rgba(76, 29, 149, 0.56)', core: '#4c1d95' },
        { main: '#9a3412', soft: 'rgba(154, 52, 18, 0.42)', glow: 'rgba(124, 45, 18, 0.56)', core: '#7c2d12' },
        { main: '#0f766e', soft: 'rgba(15, 118, 110, 0.42)', glow: 'rgba(17, 94, 89, 0.56)', core: '#115e59' },
        { main: '#86198f', soft: 'rgba(134, 25, 143, 0.42)', glow: 'rgba(112, 26, 117, 0.56)', core: '#701a75' },
        { main: '#4d7c0f', soft: 'rgba(77, 124, 15, 0.42)', glow: 'rgba(63, 98, 18, 0.56)', core: '#3f6212' },
        { main: '#9d174d', soft: 'rgba(157, 23, 77, 0.42)', glow: 'rgba(131, 24, 67, 0.56)', core: '#831843' }
    ];

    const LINE_OPTIONS = [5];

    function activePaylines() {
        return paylines.slice(0, state.lines);
    }

    function normalizeLines(value) {
        const parsed = Number(value);
        return LINE_OPTIONS.includes(parsed) ? parsed : 5;
    }

    const DEFAULT_MECHANICAL_REEL_STRIPS = [
        ['j', 'q', 'faraon', 'k', 'buburuza', 'om', 'k', 'dollar', 'j', 'scarabeu', 'a', 'k', 'buburuza', 'a', 'k', 'om', 'faraon', 'q', 'a', 'k', 'buburuza', 'scarabeu', 'k', 'faraon', 'j', 'q', 'a', 'om', 'buburuza', 'a', 'k', 'scarabeu', 'j', 'q', 'a', 'k', 'buburuza', 'a', 'k', 'iq_i', 'j', 'q', 'a', 'k', 'buburuza', 'a', 'k', 'om'],
        ['j', 'q', 'faraon', 'k', 'buburuza', 'a', 'k', 'scatter', 'j', 'scarabeu', 'a', 'k', 'buburuza', 'a', 'scatter', 'om', 'faraon', 'q', 'a', 'k', 'buburuza', 'scarabeu', 'k', 'scatter', 'j', 'q', 'a', 'k', 'buburuza', 'a', 'k', 'scatter', 'j', 'q', 'a', 'k', 'buburuza', 'a', 'k', 'iq_q', 'j', 'q', 'a', 'k', 'buburuza', 'a', 'k', 'scatter'],
        ['j', 'q', 'faraon', 'k', 'buburuza', 'om', 'a', 'dollar', 'j', 'scarabeu', 'a', 'k', 'buburuza', 'k', 'a', 'om', 'faraon', 'q', 'a', 'k', 'buburuza', 'scarabeu', 'a', 'faraon', 'j', 'q', 'a', 'om', 'buburuza', 'k', 'a', 'scarabeu', 'j', 'q', 'a', 'k', 'buburuza', 'k', 'a', 'iq_w', 'j', 'q', 'a', 'k', 'buburuza', 'k', 'a', 'om'],
        ['q', 'j', 'dollar', 'om', 'faraon', 'scatter', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'scatter', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'scatter', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'scatter', 'a', 'k', 'q', 'iq_i', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'scatter', 'iq_i', 'j', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k'],
        ['scarabeu', 'buburuza', 'a', 'k', 'dollar', 'j', 'q', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'dollar', 'j', 'iq_n', 'q', 'om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'dollar', 'j', 'iq_n', 'q', 'om', 'faraon']
    ];

    let MECHANICAL_REEL_STRIPS = DEFAULT_MECHANICAL_REEL_STRIPS.map((strip) => strip.slice());
    let mechanicalReelStripsReady = false;

    function cloneReelStrips(source) {
        return source.map((strip) => strip.slice());
    }

    function validateLoadedReelStrips(strips) {
        if (!Array.isArray(strips) || strips.length !== 5) {
            return false;
        }
        return strips.every((strip) => Array.isArray(strip) && strip.length > 0 && strip.every((symbol) => typeof symbol === 'string' && symbol));
    }

    async function loadMechanicalReelStripsManifest() {
        try {
            const response = await fetch(new URL('assets/reel-strips.json', window.location.href), { cache: 'no-store' });
            if (!response.ok) {
                return false;
            }
            const payload = await response.json();
            if (!validateLoadedReelStrips(payload?.strips)) {
                return false;
            }
            MECHANICAL_REEL_STRIPS = cloneReelStrips(payload.strips);
            mechanicalReelStripsReady = true;
            return true;
        } catch (error) {
            return false;
        }
    }

    const SCATTER_REEL_INDEXES = new Set([1, 3]);
    const symbolsBase = new URL('symbols/', window.location.href);
    const soundsBase = new URL('sounds/', window.location.href);
    const PREMIUM_LINE_WIN_SYMBOLS = new Set(['om', 'faraon', 'scarabeu', 'buburuza', 'iqwin']);
    const SMALL_LINE_WIN_SYMBOLS = new Set(['j', 'q', 'k', 'a']);
    const sampleSoundVolumes = {
        bong: 0.3,
        linewin: 1,
        lose: 1,
        up: 1
    };
    const sampleSoundFiles = {
        bong: 'bong.mp3',
        linewin: 'linewin.mp3',
        lose: '../../sounds/lose.mp3',
        up: 'up.mp3'
    };
    const sampleSoundCache = {};
    const fullSizeSymbols = new Set(['scatter', 'dollar', 'om', 'faraon', 'scarabeu', 'buburuza', 'q', 'j', 'iq_i', 'iq_q', 'iq_w', 'iq_n']);

    let iqwinSoundChain = 0;

    function resetIqwinSoundChain() {
        iqwinSoundChain = 0;
    }

    function checkIqwinReelSound(reelIndex, column) {
        if (iqwinSoundChain < 0 || reelIndex !== iqwinSoundChain) {
            return;
        }

        const expectedSymbol = IQWIN_LINE_SEQUENCE[reelIndex];
        if (!expectedSymbol || !column.includes(expectedSymbol)) {
            iqwinSoundChain = -1;
            return;
        }

        playSampleSound('up');
        iqwinSoundChain += 1;
    }

    const STOP_TIMEOUT_MS = 5000;

    const LEGACY_SPEED_KEY = 'boss_crown_speed';

    function getGameSlug() {
        const parts = window.location.pathname.split('/').filter(Boolean);
        const gamesIdx = parts.indexOf('games');
        if (gamesIdx >= 0 && parts[gamesIdx + 1]) {
            return parts[gamesIdx + 1];
        }
        return 'boss-crown';
    }

    function getSpeedPreferenceKey() {
        return `skill_slot_speed:${getGameSlug()}`;
    }

    const STOP_ALL_REEL_DELAY_MS = 25;

    const SPEED_PROFILES = {
        normal: {
            stopTimeoutMs: 5000,
            reelScrollMult: 1,
            settleManual: { duration: 0, maxDuration: 0, instant: true },
            settleAuto: { duration: 90, maxDuration: 180 },
            reelStopDelay: 160,
            winLineDuration: 540,
            winLineGap: 90,
            winSymbolLead: 180,
            winScatterHold: 720,
            spinAutoStopDelay: 480
        },
        rapid: {
            stopTimeoutMs: 5000,
            reelScrollMult: 1.5,
            settleManual: { duration: 0, maxDuration: 0, instant: true },
            settleAuto: { duration: 52, maxDuration: 105 },
            reelStopDelay: 85,
            winLineDuration: 300,
            winLineGap: 45,
            winSymbolLead: 95,
            winScatterHold: 420,
            spinAutoStopDelay: 300
        },
        turbo: {
            stopTimeoutMs: 5000,
            reelScrollMult: 2.15,
            settleManual: { duration: 0, maxDuration: 0, instant: true },
            settleAuto: { duration: 32, maxDuration: 65 },
            reelStopDelay: 40,
            winLineDuration: 165,
            winLineGap: 28,
            winSymbolLead: 55,
            winScatterHold: 240,
            spinAutoStopDelay: 180
        }
    };

    const BET_BASE_VALUES = [0.1, 0.2, 0.5, 1, 2, 3, 4, 5];
    const MIN_TOTAL_BET = 5;
    const MAX_TOTAL_BET = 20;
    const state = {
        credits: 0,
        bet: 0.1,
        betBaseIndex: 0,
        lines: 5,
        speed: 'rapid',
        soundEnabled: true,
        soundVolume: 100,
        spinning: false,
        sessionReady: true,
        playStopMode: false,
        manualStopReels: new Set(),
        stopAllUsed: false,
        skillStopSatisfied: false,
        autoStopAfterStart: false,
        autoStopping: false,
        finishingRound: false,
        stripsReady: false,
        roundBoard: null,
        roundStopIndexes: [null, null, null, null, null],
        roundStartStops: [0, 0, 0, 0, 0],
        lastSettledStops: [0, 0, 0, 0, 0],
        stoppedReels: new Set(),
        sessionId: Number(params.get('session_id') || 0) || null,
        gameId: Number(params.get('game_id') || 1) || 1,
        winCycleId: 0,
        scatterPulseTimers: [],
        iqwinPulseTimers: [],
        resolvedScatterCount: 0,
        halfBetOffer: {
            active: false,
            sessionId: null,
            gameId: null,
            betAmount: 0,
        },
        activeRound: null,
    };

    let audioCtx = null;

    function renderInfoPages() {
        const track = $('#vergaInfoTrack');
        const C = window.IqwinTerminalInfoPagesContent;
        if (!track || !C) return;

        const lineSymbols = ['om', 'faraon', 'scarabeu', 'buburuza', 'a', 'k', 'q', 'j'];
        const paySymbolScale = {
            om: 1.1,
            a: 1.24,
            k: 1.24,
            q: 1.24,
            j: 0.82
        };
        const iqwinLetters = IQWIN_LINE_SEQUENCE.map((key) => {
            const label = paytableLabels[key] || key;
            return `<img src="${symbolSrc(key)}" alt="${label}">`;
        }).join('');
        const dollarNotes = Object.keys(DOLLAR_TOTAL_BET_PAY)
            .map(Number)
            .sort((a, b) => b - a)
            .map((count) => `${count} pe linie = ${DOLLAR_TOTAL_BET_PAY[count]}x costul rundei`);

        track.innerHTML = C.compose([
            C.symbolsPage({
                brandTitle: 'Millionaire Crown',
                layout: 'rows',
                cardLayout: 'stack',
                lead: 'Toate simbolurile platesc de la stanga la dreapta pe liniile selectate, incepand cu rola din stanga. Multiplicatorii din tabel se aplica la <strong>costul rundei</strong> al rotirii.',
                cards: [
                    ...lineSymbols.map((key) => C.renderPayCard({
                        imageSrc: symbolSrc(key),
                        alt: paytableLabels[key] || key,
                        label: paytableLabels[key] || key,
                        pays: paytable[key],
                        formatEntry: (count, multiplier) => `${count} - ${multiplier}x costul rundei`,
                        symbolScale: paySymbolScale[key] || 1
                    })),
                    C.renderPayCard({
                        imageSrc: symbolSrc('dollar'),
                        alt: paytableLabels.dollar,
                        label: paytableLabels.dollar,
                        wild: true,
                        symbolScale: 1.08,
                        notesLayout: 'spread',
                        notes: dollarNotes
                    }),
                    C.renderPayCard({
                        imageSrc: symbolSrc('scatter'),
                        alt: paytableLabels.scatter,
                        label: 'Coroana Wild',
                        wild: true,
                        wildAnimated: true,
                        symbolScale: 1.08,
                        notesLayout: 'spread',
                        notes: ['Doar pe R2 si R4', 'Inlocuieste simboluri', 'Nu inlocuieste IQWIN']
                    })
                ]
            }),
            C.iqwinPage({
                brandTitle: 'Millionaire Crown',
                title: 'IQWIN',
                lead: 'Secventa speciala pe o linie activa.',
                lettersHtml: iqwinLetters,
                payText: `x5 = ${IQWIN_LINE_PAY}x costul rundei`,
                note: 'Plaseaza I · Q · W · I · N pe o linie activa, de la stanga la dreapta, pentru cel mai mare sold restituibil al jocului.'
            }),
            C.linesPage({
                lead: '5 linii fixe de plata. Toate liniile sunt active la fiecare rotire.',
                paylines: activePaylines(),
                rules: [
                    'Soldul restituibil = multiplicator x costul rundei. Costul rundei = costul pe linie x 5 linii fixe.',
                    'Dolarul plateste multiplicator x costul rundei, la fel ca celelalte simboluri.',
                    '5 role, 5 linii fixe. Opreste manual fiecare rola pentru control maxim asupra rezultatului.',
                    'Doar cel mai mare sold restituibil este acordat pe fiecare linie activa.'
                ],
                betLimits: C.getBetLimits({
                    betBaseValues: BET_BASE_VALUES,
                    minTotalBet: MIN_TOTAL_BET,
                    maxTotalBet: MAX_TOTAL_BET,
                    lineOptions: LINE_OPTIONS,
                    totalBetForBase,
                    formatBalanceNumber,
                    roundBet
                })
            }),
            C.miniGamePage({
                title: 'Quiz Millionaire',
                lead: 'Dupa o rotire fără sold restituibil, poti raspunde la o intrebare pentru recuperare partiala.',
                badgeHtml: C.textBadge('Quiz', '?'),
                paragraphs: [
                    'Primesti o intrebare cu variante de raspuns si un timp limitat.',
                    'Daca raspunzi corect la timp, primesti inapoi <strong>50% din costul rundei</strong> care a activat quiz-ul.',
                    'Dupa o rotire fara plata, butonul de quiz devine activ si poti deschide mini-jocul.'
                ]
            }),
            C.skillPage({
                gameTitle: 'Millionaire Crown',
                lead: 'Millionaire Crown nu este un joc de noroc. Rezultatul depinde de deciziile si abilitatile jucatorului.',
                mainCardText: 'Opresti manual fiecare rola. Momentul si ordinea opririlor iti apartin, iar aceste decizii influenteaza direct rezultatul rotirii.',
                miniCardTitle: 'Quiz Millionaire',
                miniCardText: 'Recuperarea depinde de cunostintele tale si de viteza cu care alegi raspunsul corect, nu de hazard.',
                footerText: 'Nici jocul principal, nici mini-jocul nu se bazeaza pe sorte intamplatoare. Ambele tin de abilitatea jucatorului.'
            })
        ]);
        if (window.IqwinTopDisplaySync) {
            window.IqwinTopDisplaySync.publishInfoPages();
        }
    }

    let infoPagesController = null;

    function setInfoPopupOpen(open) {
        if (infoPagesController) {
            infoPagesController.setOpen(open);
            return;
        }
        const popup = $('#vergaInfoPopup');
        if (!popup) return;
        popup.classList.toggle('is-hidden', !open);
    }

    function delay(ms) {
        return new Promise((resolve) => window.setTimeout(resolve, ms));
    }

    function getSpeedProfile() {
        return SPEED_PROFILES.rapid;
    }

    function getStopTimeoutMs() {
        return STOP_TIMEOUT_MS;
    }

    function getStopTimeoutSeconds() {
        return Math.max(1, Math.ceil(getStopTimeoutMs() / 1000));
    }

    function ensureAudio() {
        if (!window.AudioContext && !window.webkitAudioContext) {
            return null;
        }
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
        return audioCtx;
    }

    function playTone(options = {}) {
        if (!state.soundEnabled) {
            return;
        }
        const ctx = ensureAudio();
        if (!ctx) {
            return;
        }

        const {
            frequency = 440,
            endFrequency = frequency,
            duration = 0.08,
            type = 'sine',
            gain = 0.08,
            delayTime = 0
        } = options;

        const start = ctx.currentTime + delayTime;
        const end = start + duration;
        const osc = ctx.createOscillator();
        const amp = ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(frequency, start);
        osc.frequency.exponentialRampToValueAtTime(Math.max(40, endFrequency), end);
        amp.gain.setValueAtTime(0.0001, start);
        amp.gain.exponentialRampToValueAtTime(gain * getSoundVolumeMultiplier(), start + 0.01);
        amp.gain.exponentialRampToValueAtTime(0.0001, end);
        osc.connect(amp);
        amp.connect(ctx.destination);
        osc.start(start);
        osc.stop(end + 0.02);
    }

    function playSampleSound(name) {
        if (!state.soundEnabled) {
            return;
        }

        const fileName = sampleSoundFiles[name];
        if (!fileName) {
            return;
        }

        ensureAudio();

        try {
            if (!sampleSoundCache[name]) {
                const audioUrlRaw = fileName.includes('/')
                    ? new URL(fileName, window.location.href).href
                    : new URL(fileName, soundsBase).href;
                const audioUrl = window.IqwinLocalAssets && typeof window.IqwinLocalAssets.resolve === 'function'
                    ? window.IqwinLocalAssets.resolve(audioUrlRaw)
                    : audioUrlRaw;
                const audio = new Audio(audioUrl);
                audio.preload = 'auto';
                sampleSoundCache[name] = audio;
            }

            const audio = sampleSoundCache[name];
            audio.volume = (sampleSoundVolumes[name] ?? 1) * getSoundVolumeMultiplier();
            audio.currentTime = 0;
            const playPromise = audio.play();
            if (playPromise && typeof playPromise.catch === 'function') {
                playPromise.catch(() => {});
            }
        } catch (error) {
        }
    }

    function shouldPlayLineWinSound(win) {
        if (!win || win.line <= 0) {
            return false;
        }
        if (PREMIUM_LINE_WIN_SYMBOLS.has(win.symbol)) {
            return win.count >= 3;
        }
        if (SMALL_LINE_WIN_SYMBOLS.has(win.symbol)) {
            return win.count >= 4;
        }
        return false;
    }

    function hasLineWinSound(wins) {
        return (wins || []).some(shouldPlayLineWinSound);
    }

    function playGameSound(name) {
        if (!state.soundEnabled) {
            return;
        }

        if (name === 'spin') {
            playTone({ frequency: 180, endFrequency: 95, duration: 0.14, type: 'triangle', gain: 0.06 });
            playTone({ frequency: 320, endFrequency: 210, duration: 0.1, type: 'sine', gain: 0.04, delayTime: 0.03 });
            return;
        }

        if (name === 'stop') {
            playTone({ frequency: 520, endFrequency: 280, duration: 0.07, type: 'square', gain: 0.045 });
            playTone({ frequency: 140, endFrequency: 90, duration: 0.09, type: 'triangle', gain: 0.05 });
            return;
        }

        if (name === 'win') {
            playTone({ frequency: 440, endFrequency: 660, duration: 0.12, type: 'sine', gain: 0.07 });
            playTone({ frequency: 660, endFrequency: 880, duration: 0.14, type: 'sine', gain: 0.06, delayTime: 0.08 });
            playTone({ frequency: 880, endFrequency: 1175, duration: 0.16, type: 'triangle', gain: 0.05, delayTime: 0.16 });
            return;
        }

        if (name === 'scatter') {
            playTone({ frequency: 620, endFrequency: 280, duration: 0.22, type: 'sine', gain: 0.09 });
            playTone({ frequency: 980, endFrequency: 520, duration: 0.16, type: 'triangle', gain: 0.06, delayTime: 0.04 });
            playTone({ frequency: 180, endFrequency: 95, duration: 0.28, type: 'sine', gain: 0.07, delayTime: 0.02 });
        }
    }

    function loadPreferences() {
        try {
            const speedKey = getSpeedPreferenceKey();
            let savedSpeed = localStorage.getItem(speedKey);
            if (!savedSpeed) {
                savedSpeed = localStorage.getItem(LEGACY_SPEED_KEY);
            }
            state.speed = 'rapid';
            state.soundEnabled = localStorage.getItem('boss_crown_mute') !== '1';
            const savedVolume = localStorage.getItem(VOLUME_STORAGE_KEY);
            if (savedVolume !== null && savedVolume !== '') {
                state.soundVolume = Math.max(0, Math.min(100, Number(savedVolume) || 0));
                state.soundEnabled = state.soundVolume > 0;
            }
            state.playStopMode = localStorage.getItem('boss_crown_play_stop') === '1';
        } catch (error) {
        }
    }

    function saveSpeedPreference() {
        try {
            localStorage.setItem(getSpeedPreferenceKey(), state.speed);
            localStorage.setItem(LEGACY_SPEED_KEY, state.speed);
        } catch (error) {
        }
    }


    const VOLUME_STORAGE_KEY = 'iqwin_terminal_volume';

    function getSoundVolumeMultiplier() {
        if (!state.soundEnabled) {
            return 0;
        }
        return Math.max(0, Math.min(1, Number(state.soundVolume || 0) / 100));
    }

    function saveVolumePreference() {
        try {
            localStorage.setItem(VOLUME_STORAGE_KEY, String(Math.max(0, Math.min(100, Math.round(Number(state.soundVolume) || 0)))));
        } catch (error) {
        }
    }

    function saveSoundPreference() {
        try {
            localStorage.setItem('boss_crown_mute', state.soundEnabled ? '0' : '1');
        } catch (error) {
        }
    
        saveVolumePreference();
    }

    function savePlayStopPreference() {
        try {
            localStorage.setItem('boss_crown_play_stop', state.playStopMode ? '1' : '0');
        } catch (error) {
        }
    }

    function updateSpeedButtons() {
        settingsController?.refresh();
        const stopSeconds = getStopTimeoutSeconds();
        $$('.verga-stop-btn .verga-stop-seconds').forEach((node) => {
            if (!node.closest('.verga-stop-btn')?.classList.contains('is-stopped')) {
                node.textContent = String(stopSeconds);
            }
        });
    }

    let settingsController = null;

    function initSettingsMenu() {
        if (typeof IqwinTerminalSettings === 'undefined') {
            return;
        }
        settingsController = IqwinTerminalSettings.bind({
            getSpeed: () => state.speed,
            setSpeed: (speed) => {
                if (state.spinning || !SPEED_PROFILES[speed]) {
                    return;
                }
                state.speed = speed;
                saveSpeedPreference();
                ensureAudio();
                playTone({ frequency: 420, endFrequency: 520, duration: 0.06, type: 'triangle', gain: 0.04 });
            },
            speedOrder: ['rapid'],
            forceSpeed: 'rapid',
            getVolume: () => state.soundVolume,
            setVolume: (volume) => {
                state.soundVolume = Math.max(0, Math.min(100, Math.round(Number(volume) || 0)));
                state.soundEnabled = state.soundVolume > 0;
                saveSoundPreference();
            },
            setSoundEnabled: (enabled) => {
                state.soundEnabled = Boolean(enabled);
                if (!state.soundEnabled) {
                    state.soundVolume = 0;
                } else if (state.soundVolume <= 0) {
                    state.soundVolume = 100;
                }
                saveSoundPreference();
            },
            isLocked: () => state.spinning,
            onSpeedChange: () => {
                updateSpeedButtons();
            }
        });
    }

    function updatePreferenceControls() {
        updateSpeedButtons();
        updateSpinModeToggle();
        updateSpinButton();
    }

    function updateSpinModeToggle() {
        const btn = $('#spinModeToggle');
        if (!btn) return;

        const active = state.playStopMode;
        btn.textContent = active ? 'NM' : 'PS';
        btn.classList.toggle('is-active', active);
        btn.setAttribute('aria-pressed', active ? 'true' : 'false');
        btn.disabled = state.spinning;
        if (active) {
            btn.setAttribute('aria-label', 'Mod normal');
            btn.setAttribute('title', 'Mod normal');
        } else {
            btn.setAttribute('aria-label', 'Play + Stop automat');
            btn.setAttribute('title', 'Play + Stop automat');
        }
    }

    function symbolSrc(key) {
        const href = new URL(symbolFiles[key] || 'q.webp', symbolsBase).href;
        return window.IqwinLocalAssets && typeof window.IqwinLocalAssets.resolve === 'function'
            ? window.IqwinLocalAssets.resolve(href)
            : href;
    }

    function formatAmount(value) {
        return Number(value || 0).toLocaleString('ro-RO', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    }

    function formatBetNumber(value) {
        return Number(value || 0).toLocaleString('ro-RO', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    }

    function formatBalanceNumber(value) {
        return Number(value || 0).toLocaleString('ro-RO', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function roundBet(value) {
        return Math.round((Number(value) || 0) * 100) / 100;
    }

    function toDisplayCredits(serverCredits) {
        var display = window.IqwinTerminalCreditsDisplay;
        if (display && typeof display.moneyForCredits === 'function') {
            return roundBet(display.moneyForCredits(serverCredits));
        }
        return roundBet(Number(serverCredits) || 0);
    }

    function isBetBaseAllowed(basePerLine) {
        const total = totalBetForBase(basePerLine);
        if (total < MIN_TOTAL_BET || total > MAX_TOTAL_BET) {
            return false;
        }
        if (typeof IqwinTerminalBetButtons !== 'undefined'
            && IqwinTerminalBetButtons.isTotalBetLeiBlockedForLines(total, state.lines)) {
            return false;
        }
        return true;
    }

    function getBetBaseValues() {
        return BET_BASE_VALUES.filter(isBetBaseAllowed);
    }

    function resolveBetBaseIndex() {
        const values = getBetBaseValues();
        if (!values.length) {
            state.betBaseIndex = BET_BASE_VALUES.length - 1;
            state.bet = BET_BASE_VALUES[state.betBaseIndex];
            return;
        }
        const current = roundBet(state.bet);
        let idx = values.findIndex((value) => roundBet(value) === current);
        if (idx < 0) {
            idx = values.findIndex((value) => roundBet(value) > current);
            if (idx < 0) idx = 0;
        }
        state.betBaseIndex = idx;
        syncEffectiveBet();
    }

    function clampBetBaseIndex() {
        const values = getBetBaseValues();
        state.betBaseIndex = Math.max(0, Math.min(values.length - 1, state.betBaseIndex));
    }

    function getCurrentBetBase() {
        const values = getBetBaseValues();
        clampBetBaseIndex();
        return values[state.betBaseIndex] ?? values[0] ?? 1;
    }

    function calcWinPayout(multiplier) {
        const payout = roundBet(totalBetAmount() * (Number(multiplier) || 0));
        return payout > 0 ? payout : 0;
    }

    function calcTotalBetPayout(multiplier) {
        const payout = roundBet(totalBetAmount() * (Number(multiplier) || 0));
        return payout > 0 ? payout : 0;
    }

    function syncEffectiveBet() {
        state.bet = roundBet(getCurrentBetBase());
    }

    let betButtonsController = null;

    function initBetButtons() {
        if (typeof IqwinTerminalBetButtons === 'undefined') return;
        betButtonsController = IqwinTerminalBetButtons.create({
            getValues: getBetBaseValues,
            getIndex: () => state.betBaseIndex,
            setIndex: (index) => {
                state.betBaseIndex = index;
                syncEffectiveBet();
            },
            isLocked: () => state.spinning,
            formatValue: formatBetNumber,
            getDisplayValue: (baseValue) => totalBetForBase(baseValue),
            onChange: updateBetLabel
        });
        betButtonsController.bind();
    }

    function updateBetStepperUI(renderOptions) {
        syncEffectiveBet();
        betButtonsController?.render(renderOptions);
    }

    function applyUniformCellStyle(cell) {
        if (!cell) return;
        cell.style.removeProperty('background-color');
        cell.style.setProperty('overflow', 'hidden', 'important');
        const isScatterCell = Boolean(cell.querySelector('img[data-symbol="scatter"], img[data-symbol="dollar"]'));
        if (isScatterCell) {
            cell.style.setProperty('display', 'grid', 'important');
            cell.style.setProperty('place-items', 'center', 'important');
        } else {
            cell.style.setProperty('display', 'block', 'important');
            cell.style.removeProperty('place-items');
        }
    }

    function applyUniformImageStyle(image) {
        if (!image) return;
        const isScatter = image.dataset.symbol === 'scatter' || image.dataset.symbol === 'dollar';
        const size = isScatter ? '84%' : '100%';
        image.style.setProperty('width', size, 'important');
        image.style.setProperty('height', size, 'important');
        image.style.setProperty('max-width', isScatter ? size : 'none', 'important');
        image.style.setProperty('max-height', isScatter ? size : 'none', 'important');
        image.style.setProperty('object-fit', isScatter ? 'contain' : 'fill', 'important');
        image.style.setProperty('display', 'block', 'important');
        if (isScatter) {
            image.style.setProperty('object-position', 'center center', 'important');
            image.style.setProperty('margin', '0', 'important');
        } else {
            image.style.removeProperty('object-position');
            image.style.removeProperty('margin');
            image.style.removeProperty('max-width');
            image.style.removeProperty('max-height');
        }
    }

    function applyUniformStyles() {
        $$('.boss-crown-reel').forEach((reel) => {
            reel.style.setProperty('background', 'transparent', 'important');
            reel.style.setProperty('box-shadow', 'none', 'important');
        });
        $$('.boss-crown-cell, .boss-crown-spin-strip-item').forEach(applyUniformCellStyle);
        $$('.boss-crown-cell img, .boss-crown-spin-strip-item img').forEach(applyUniformImageStyle);
    }

    function setCellSymbol(cell, key) {
        const image = cell.querySelector('img');
        if (!image) return;
        image.dataset.symbol = key;
        image.src = symbolSrc(key);
        applyUniformCellStyle(cell);
        applyUniformImageStyle(image);
    }

    function getMechanicalReelStrip(reelIndex) {
        return MECHANICAL_REEL_STRIPS[reelIndex] || MECHANICAL_REEL_STRIPS[0];
    }

    function readMechanicalColumn(reelIndex, stopIndex) {
        const strip = getMechanicalReelStrip(reelIndex);
        const top = ((stopIndex % strip.length) + strip.length) % strip.length;
        return [0, 1, 2].map((row) => strip[(top + row) % strip.length]);
    }

    function columnsMatch(left, right) {
        if (!Array.isArray(left) || !Array.isArray(right) || left.length !== 3 || right.length !== 3) {
            return false;
        }
        return left[0] === right[0] && left[1] === right[1] && left[2] === right[2];
    }

    function findStopIndexForColumn(reelIndex, column, preferred = null) {
        if (!Array.isArray(column) || column.length !== 3) {
            return null;
        }
        const strip = getMechanicalReelStrip(reelIndex);
        const matches = [];
        for (let stopIndex = 0; stopIndex < strip.length; stopIndex += 1) {
            if (columnsMatch(readMechanicalColumn(reelIndex, stopIndex), column)) {
                matches.push(stopIndex);
            }
        }
        if (!matches.length) {
            return null;
        }
        if (preferred !== null && preferred !== undefined) {
            const normalizedPreferred = normalizeStopIndex(reelIndex, preferred);
            if (matches.includes(normalizedPreferred)) {
                return normalizedPreferred;
            }
        }
        return matches[0];
    }

    function normalizeStopIndex(reelIndex, stopIndex) {
        const strip = getMechanicalReelStrip(reelIndex);
        const length = strip.length;
        if (!Number.isFinite(stopIndex)) {
            return null;
        }
        return ((Math.round(stopIndex) % length) + length) % length;
    }

    function readBoardFromVisibleCells() {
        const board = createEmptyRoundBoard();
        let complete = true;
        for (let reelIndex = 0; reelIndex < 5; reelIndex += 1) {
            const column = [0, 1, 2].map((row) => {
                const image = document.querySelector(`[data-position="${reelIndex}-${row}"] img`);
                const symbol = image?.dataset?.symbol;
                if (!symbol) {
                    complete = false;
                    return null;
                }
                return symbol;
            });
            if (column.some((symbol) => !symbol)) {
                complete = false;
            }
            board[reelIndex] = column;
        }
        return complete ? board : null;
    }

    function resolveMissingStopIndexes(sourceBoard = state.roundBoard) {
        for (let reelIndex = 0; reelIndex < 5; reelIndex += 1) {
            const column = sourceBoard?.[reelIndex];
            if (!Array.isArray(column) || column.some((symbol) => !symbol)) {
                continue;
            }
            const current = state.roundStopIndexes[reelIndex];
            if (current !== null && current !== undefined) {
                const normalized = normalizeStopIndex(reelIndex, current);
                if (columnsMatch(readMechanicalColumn(reelIndex, normalized), column)) {
                    state.roundStopIndexes[reelIndex] = normalized;
                    continue;
                }
            }
            const preferred = (current !== null && current !== undefined) ? current : null;
            const resolved = findStopIndexForColumn(reelIndex, column, preferred);
            if (resolved !== null) {
                state.roundStopIndexes[reelIndex] = resolved;
            }
        }
    }

    function buildRoundBoardFromStopIndexes() {
        const board = createEmptyRoundBoard();
        for (let reelIndex = 0; reelIndex < 5; reelIndex += 1) {
            const stopIndex = state.roundStopIndexes[reelIndex];
            if (stopIndex === null || stopIndex === undefined) {
                return null;
            }
            board[reelIndex] = readMechanicalColumn(reelIndex, stopIndex);
        }
        return board;
    }

    function reconcileAllRoundStops() {
        const visibleBoard = readBoardFromVisibleCells();
        if (visibleBoard) {
            state.roundBoard = visibleBoard.map((column) => column.slice());
        }
        resolveMissingStopIndexes(state.roundBoard);
    }

    function finalizeRoundState() {
        reconcileAllRoundStops();
    }

    function hasCompleteRoundStops() {
        const board = readBoardFromVisibleCells() || state.roundBoard;
        if (!board) {
            return false;
        }
        return board.every((column) => (
            Array.isArray(column) && column.length === 3 && column.every((symbol) => Boolean(symbol))
        ));
    }

    let autoStopChain = Promise.resolve();

    function readVisibleStripColumn(reelNode, reelIndex) {
        const strip = reelNode.querySelector('.boss-crown-spin-strip');
        if (!strip || !strip.children.length) return null;
        const spinLength = Number(strip.dataset.spinLength) || getMechanicalReelStrip(reelIndex).length;
        if (spinLength <= 0) return null;
        const reelRows = 3;
        const reelRect = reelNode.getBoundingClientRect();
        let sampledIndex = null;
        if (reelRect.height > 0) {
            const targetY = reelRect.top + (reelRect.height / (reelRows * 2));
            let bestDist = Infinity;
            for (let i = 0; i < strip.children.length; i += 1) {
                const box = strip.children[i].getBoundingClientRect();
                if (box.height <= 0) continue;
                const dist = Math.abs((box.top + (box.height / 2)) - targetY);
                if (dist < bestDist) {
                    bestDist = dist;
                    sampledIndex = i;
                }
            }
        }
        let topIndex = sampledIndex;
        if (topIndex !== null) {
            topIndex = ((topIndex % spinLength) + spinLength) % spinLength;
        }
        if (topIndex === null) {
            const rowHeight = getStripRowHeight(strip);
            if (rowHeight <= 0) return null;
            let offset = readStripOffset(strip, reelNode);
            const loopHeight = rowHeight * spinLength;
            offset = ((offset % loopHeight) + loopHeight) % loopHeight;
            topIndex = ((Math.round(offset / rowHeight) % spinLength) + spinLength) % spinLength;
            sampledIndex = topIndex;
        }
        const sourceIndex = sampledIndex === null ? topIndex : sampledIndex;
        const mechanical = readMechanicalColumn(reelIndex, topIndex);
        const column = Array.from({ length: reelRows }, (_, row) => {
            const img = strip.children[sourceIndex + row]?.querySelector('img');
            const symbol = img?.dataset.symbol;
            if (symbol) return symbol;
            return mechanical[row];
        });
        if (column.some((symbol) => !symbol)) return null;
        const matchedStop = findStopIndexForColumn(reelIndex, column, topIndex);
        return { column, stopIndex: matchedStop === null ? topIndex : matchedStop };
    }

    function freezeReelOnStop(reelIndex, source) {
        const reelNode = $(`.boss-crown-reel[data-reel="${reelIndex}"]`);
        if (!reelNode) return;
        stopStripScroll(reelNode);
        reelNode.classList.add('is-reel-freezing');
        const lockSource = source || 'player';
        const strip = reelNode.querySelector('.boss-crown-spin-strip');
        const stripLength = Number(strip?.dataset.spinLength) || getMechanicalReelStrip(reelIndex).length;
        const visible = readVisibleStripColumn(reelNode, reelIndex);
        let lockedStop = visible?.stopIndex ?? null;
        if (lockedStop === null && window.IqwinSkillSpin) {
            const elapsed = window.IqwinSkillSpin.captureElapsed(state, lockSource);
            lockedStop = window.IqwinSkillSpin.localStopIndex(state, reelIndex, lockSource, stripLength, elapsed);
            lockedStop = ((Number(lockedStop) % stripLength) + stripLength) % stripLength;
        }
        if (lockedStop === null) return;
        if (strip) {
            strip.dataset.resolvedStopIndex = String(lockedStop);
        }
        if (window.IqwinSkillSpin) {
            const clock = window.IqwinSkillSpin.captureElapsed(state, lockSource);
            const elapsed = typeof window.IqwinSkillSpin.elapsedMatchingStop === 'function'
                ? window.IqwinSkillSpin.elapsedMatchingStop(state, reelIndex, lockedStop, stripLength, clock, lockSource)
                : clock;
            window.IqwinSkillSpin.rememberClickElapsed(state, [reelIndex], elapsed);
        }
        state.roundStopIndexes[reelIndex] = lockedStop;
        if (!state.roundBoard) state.roundBoard = createEmptyRoundBoard();
        state.roundBoard[reelIndex] = visible?.column ? visible.column.slice() : readMechanicalColumn(reelIndex, lockedStop);
        state.roundBoard[reelIndex].forEach((symbol, row) => {
            const cell = $(`[data-position="${reelIndex}-${row}"]`);
            if (cell) setCellSymbol(cell, symbol);
        });
    }

    function freezeAllSpinningReels() {
        [0, 1, 2, 3, 4].forEach((reelIndex) => {
            if (state.stoppedReels.has(reelIndex)) return;
            const reelNode = $(`.boss-crown-reel[data-reel="${reelIndex}"]`);
            if (!reelNode?.classList.contains('is-spinning')) return;
            freezeReelOnStop(reelIndex);
        });
    }

    async function waitForRevealsIdle(maxMs = 8000) {
        const deadline = Date.now() + maxMs;
        while (Date.now() < deadline) {
            if (!state.spinning) return;
            if (revealingReels.size === 0) return;
            await delay(16);
        }
    }

    async function waitForAllReelsSettled(maxMs = 12000) {
        const deadline = Date.now() + maxMs;
        while (Date.now() < deadline) {
            if (!state.spinning) return;
            if (state.stoppedReels.size >= 5 && revealingReels.size === 0) {
                return;
            }
            await delay(32);
        }
    }

    function randomReelColumn(reelIndex) {
        const start = Number(state.roundStartStops?.[reelIndex] ?? state.lastSettledStops?.[reelIndex] ?? 0);
        return readMechanicalColumn(reelIndex, start);
    }

    function createEmptyRoundBoard() {
        return Array.from({ length: 5 }, () => null);
    }

    const stripScrollLoops = new WeakMap();
    const STRIP_LOOP_TAIL = 3;

    function removeSpinStrip(reel) {
        stopStripScroll(reel);
        reel?.querySelector('.boss-crown-spin-strip')?.remove();
    }

    function clearSpinStrip(reel) {
        removeSpinStrip(reel);
        reel?.classList.remove('is-reel-settling', 'is-spinning');
    }

    function stopStripScroll(reel) {
        if (window.IqwinBrainReels) {
            window.IqwinBrainReels.stop(reel, stripScrollLoops);
            return;
        }
        const loop = stripScrollLoops.get(reel);
        if (!loop) return;
        loop.cancelled = true;
        if (loop.frameId) cancelAnimationFrame(loop.frameId);
        const strip = reel.querySelector('.boss-crown-spin-strip');
        if (strip) {
            strip.style.transform = `translate3d(0, ${-loop.offset}px, 0)`;
        }
        stripScrollLoops.delete(reel);
    }

    function prepareReelStripSymbols(reelIndex) {
        const base = getMechanicalReelStrip(reelIndex).slice();
        const loopTail = base.slice(0, STRIP_LOOP_TAIL);
        return {
            symbols: base.concat(base, loopTail),
            spinLength: base.length
        };
    }

    function readStripOffset(strip, reel) {
        const loop = stripScrollLoops.get(reel);
        if (loop) return loop.offset;
        const match = strip.style.transform.match(/,\s*(-?[\d.]+)px/);
        return match ? Math.abs(parseFloat(match[1])) : 0;
    }

    function getStripRowHeight(strip) {
        const firstItem = strip?.children?.[0];
        if (!firstItem) return 0;
        return firstItem.getBoundingClientRect().height;
    }

    async function waitForStripRowHeight(strip, attempts = 8) {
        for (let attempt = 0; attempt < attempts; attempt += 1) {
            const rowHeight = getStripRowHeight(strip);
            if (rowHeight > 0) {
                return rowHeight;
            }
            await new Promise((resolve) => requestAnimationFrame(resolve));
        }
        return 0;
    }

    function readSettledColumnFromStrip(reelNode, reelIndex) {
        const strip = reelNode.querySelector('.boss-crown-spin-strip');
        if (!strip || !strip.children.length) return null;

        const rowHeight = getStripRowHeight(strip);
        if (rowHeight <= 0) return null;

        const spinLength = Number(strip.dataset.spinLength) || getMechanicalReelStrip(reelIndex).length;
        let stopIndex = null;
        if (strip.dataset.resolvedStopIndex !== undefined && strip.dataset.resolvedStopIndex !== '') {
            stopIndex = normalizeStopIndex(reelIndex, Number(strip.dataset.resolvedStopIndex));
        } else {
            let offset = readStripOffset(strip, reelNode);
            const loopHeight = rowHeight * spinLength;
            while (offset >= loopHeight) offset -= loopHeight;
            stopIndex = normalizeStopIndex(reelIndex, Math.floor(offset / rowHeight));
        }

        const column = [0, 1, 2].map((row) => {
            const child = strip.children[stopIndex + row];
            return child?.querySelector('img')?.dataset?.symbol || null;
        });
        if (column.some((symbol) => !symbol)) {
            return null;
        }

        return {
            stopIndex,
            column
        };
    }

    function readReelStopIndex(reelNode, reelIndex) {
        const strip = reelNode.querySelector('.boss-crown-spin-strip');
        if (!strip || !strip.children.length) return null;

        if (strip.dataset.resolvedStopIndex !== undefined && strip.dataset.resolvedStopIndex !== '') {
            return normalizeStopIndex(reelIndex, Number(strip.dataset.resolvedStopIndex));
        }

        const rowHeight = getStripRowHeight(strip);
        if (rowHeight <= 0) return null;

        const spinLength = Number(strip.dataset.spinLength) || getMechanicalReelStrip(reelIndex).length;
        const loopHeight = rowHeight * spinLength;
        let offset = readStripOffset(strip, reelNode);
        while (offset >= loopHeight) offset -= loopHeight;

        return normalizeStopIndex(reelIndex, Math.floor(offset / rowHeight));
    }

    function readReelOutcomeFromStrip(reelNode, reelIndex) {
        const settled = readSettledColumnFromStrip(reelNode, reelIndex);
        if (settled?.column) {
            return settled.column;
        }
        let stopIndex = readReelStopIndex(reelNode, reelIndex);
        if (stopIndex === null) {
            stopIndex = 0;
        }
        return readMechanicalColumn(reelIndex, stopIndex);
    }

    function settleReelToNearestRow(reelNode, profile = 'manual') {
        const strip = reelNode.querySelector('.boss-crown-spin-strip');
        if (!strip) return Promise.resolve();

        stopStripScroll(reelNode);

        if (!strip.children.length) return Promise.resolve();

        return (async () => {
            let rowHeight = getStripRowHeight(strip);
            if (rowHeight <= 0) {
                rowHeight = await waitForStripRowHeight(strip, profile === 'manual' ? 2 : 8);
            }
            if (rowHeight <= 0) return;

            const reelIndex = Number(reelNode.dataset.reel || 0);
            const spinLength = Number(strip.dataset.spinLength) || getMechanicalReelStrip(reelIndex).length;
            const loopHeight = rowHeight * spinLength;

            let current = readStripOffset(strip, reelNode);
            while (current >= loopHeight) current -= loopHeight;

            const from = current;
            const to = profile === 'auto'
                ? Math.floor(current / rowHeight) * rowHeight
                : Math.round(current / rowHeight) * rowHeight;
            const presets = {
                manual: getSpeedProfile().settleManual,
                auto: getSpeedProfile().settleAuto
            };
            const preset = presets[profile] || presets.manual;
            const travelRows = Math.max(0, Math.abs(to - from) / rowHeight);
            const resolvedStopIndex = normalizeStopIndex(reelIndex, Math.floor(to / rowHeight));

            const applySettledPosition = () => {
                strip.style.transform = `translate3d(0, ${-to}px, 0)`;
                if (resolvedStopIndex !== null) {
                    strip.dataset.resolvedStopIndex = String(resolvedStopIndex);
                }
            };

            if (preset.instant || preset.duration <= 0) {
                applySettledPosition();
                return;
            }

            let settleDuration = Math.max(preset.duration, 50 + travelRows * 14);
            if (preset.maxDuration) settleDuration = Math.min(settleDuration, preset.maxDuration);

            await new Promise((resolve) => {
                const start = performance.now();
                const step = (now) => {
                    const progress = Math.min(1, (now - start) / settleDuration);
                    const eased = 1 - Math.pow(1 - progress, 3);
                    const value = from + (to - from) * eased;
                    strip.style.transform = `translate3d(0, ${-value}px, 0)`;
                    if (progress < 1) {
                        requestAnimationFrame(step);
                    } else {
                        applySettledPosition();
                        resolve();
                    }
                };
                requestAnimationFrame(step);
            });
        })();
    }

    function startStripScroll(reel, reelIndex) {
        const spinLength = getMechanicalReelStrip(reelIndex).length;
        const startStop = state.roundStartStops?.[reelIndex] ?? 0;
        if (window.IqwinBrainReels) {
            window.IqwinBrainReels.start(reel, reelIndex, stripScrollLoops, spinLength, startStop);
        }
    }

    function createSpinStrip(reel, reelIndex) {
        removeSpinStrip(reel);
        const strip = document.createElement('div');
        strip.className = 'boss-crown-spin-strip';
        const prepared = prepareReelStripSymbols(reelIndex);
        const symbols = prepared.symbols;

        strip.dataset.spinLength = String(prepared.spinLength);
        strip.style.setProperty('--verga-strip-rows', String(symbols.length));
        strip.style.height = `calc(${symbols.length} * (100% / 3))`;
        strip.style.gridTemplateRows = `repeat(${symbols.length}, calc(100% / ${symbols.length}))`;

        symbols.forEach((symbol) => {
            const item = document.createElement('div');
            item.className = 'boss-crown-spin-strip-item';
            applyUniformCellStyle(item);
            const image = document.createElement('img');
            image.src = symbolSrc(symbol);
            image.alt = '';
            image.dataset.symbol = symbol;
            image.loading = 'eager';
            applyUniformImageStyle(image);
            item.append(image);
            strip.append(item);
        });

        reel.append(strip);
        requestAnimationFrame(() => startStripScroll(reel, reelIndex));
    }

    const timers = {
        autoStop: null,
        countdown: null,
        quickAutoStop: null,
        stopArm: null
    };

    function clearStopTimers() {
        if (timers.autoStop) window.clearTimeout(timers.autoStop);
        if (timers.countdown) window.clearInterval(timers.countdown);
        if (timers.quickAutoStop) window.clearTimeout(timers.quickAutoStop);
        if (timers.stopArm) window.clearTimeout(timers.stopArm);
        timers.autoStop = null;
        timers.countdown = null;
        timers.quickAutoStop = null;
        timers.stopArm = null;
    }

    function playerStopArmed() {
        return window.IqwinSkillSpin && typeof window.IqwinSkillSpin.isPlayerStopArmed === 'function'
            ? window.IqwinSkillSpin.isPlayerStopArmed(state)
            : true;
    }

    function enableArmedStopButtons() {
        document.body.classList.remove('is-stop-arm-locked');
        if (!state.spinning || state.autoStopping || state.finishingRound) return;
        if (!playerStopArmed()) return;
        if (!state.autoStopAfterStart) {
            $$('.verga-stop-btn').forEach((btn) => {
                if (!btn.classList.contains('is-stopped')) btn.disabled = false;
            });
        }
        updateSpinButton();
    }

    function schedulePlayerStopArm() {
        if (timers.stopArm) window.clearTimeout(timers.stopArm);
        timers.stopArm = null;
        if (!state.spinning || state.autoStopping) return;
        const wait = window.IqwinSkillSpin && typeof window.IqwinSkillSpin.remainingArmMs === 'function'
            ? window.IqwinSkillSpin.remainingArmMs(state)
            : 0;
        if (wait <= 0) {
            enableArmedStopButtons();
            return;
        }
        $$('.verga-stop-btn').forEach((btn) => {
            btn.disabled = true;
        });
        updateSpinButton();
        timers.stopArm = window.setTimeout(() => {
            timers.stopArm = null;
            enableArmedStopButtons();
        }, wait);
    }

    function resetStopButtonVisuals(btn) {
        if (!btn) return;
        btn.classList.remove('is-counting', 'is-stopped');
        const seconds = btn.querySelector('.verga-stop-seconds');
        if (seconds) {
            seconds.textContent = String(getStopTimeoutSeconds());
            seconds.removeAttribute('aria-hidden');
        }
    }

    function setStopSecondPhase(secs) {
        const stops = $('#reelStops');
        if (!stops) return;
        stops.classList.remove('is-stop-sec-5', 'is-stop-sec-4', 'is-stop-sec-3', 'is-stop-sec-2', 'is-stop-sec-1');
        if (secs >= 5) stops.classList.add('is-stop-sec-5');
        else if (secs === 4) stops.classList.add('is-stop-sec-4');
        else if (secs === 3) stops.classList.add('is-stop-sec-3');
        else if (secs === 2) stops.classList.add('is-stop-sec-2');
        else if (secs === 1) stops.classList.add('is-stop-sec-1');
    }

    function clearStopSecondPhase() {
        $('#reelStops')?.classList.remove('is-stop-sec-5', 'is-stop-sec-4', 'is-stop-sec-3', 'is-stop-sec-2', 'is-stop-sec-1');
    }

    function setStopCountdownActive(active) {
        const stops = $('#reelStops');
        stops?.classList.toggle('is-countdown-active', active);
        if (!active) clearStopSecondPhase();
    }

function runStopCountdownPhase(timeoutMs) {
        const deadline = Date.now() + timeoutMs;
        const stops = $('#reelStops');
        const initialSeconds = getStopTimeoutSeconds();

        $$('.verga-stop-btn').forEach((btn) => {
            if (btn.classList.contains('is-stopped')) return;
            btn.classList.add('is-counting');
        });

        if (stops) {
            stops.style.setProperty('--verga-stop-countdown-duration', timeoutMs + 'ms');
            stops.offsetHeight;
            setStopCountdownActive(true);
            setStopSecondPhase(initialSeconds);
        }

        const tick = () => {
            const left = Math.max(0, deadline - Date.now());
            const secs = Math.max(0, Math.ceil(left / 1000));
            setStopSecondPhase(secs);
            $$('.verga-stop-btn').forEach((btn) => {
                if (btn.classList.contains('is-stopped')) return;
                const node = btn.querySelector('.verga-stop-seconds');
                if (node) node.textContent = String(secs);
            });
            if (left <= 0 && timers.countdown) {
                window.clearInterval(timers.countdown);
                timers.countdown = null;
            }
        };

        tick();
        timers.countdown = window.setInterval(tick, 50);

        timers.autoStop = window.setTimeout(() => {
            if (!state.sessionReady) {
                return;
            }
            playSampleSound('lose');
            autoStopAllReels();
        }, timeoutMs);
    }

    function startStopCountdown({ enableButtons = true } = {}) {
        clearStopTimers();
        const timeoutMs = getStopTimeoutMs();

        setStopCountdownActive(false);
        $$('.verga-stop-btn').forEach((btn) => {
            resetStopButtonVisuals(btn);
            btn.disabled = true;
        });

        runStopCountdownPhase(timeoutMs);
        if (enableButtons) {
            schedulePlayerStopArm();
        }
    }

    const revealingReels = new Set();

    async function waitForReelStopped(reelIndex, maxMs = 12000) {
        const deadline = Date.now() + maxMs;
        while (state.spinning && !state.stoppedReels.has(reelIndex) && Date.now() < deadline) {
            await delay(32);
        }
    }

    async function waitForAllReelsStopped(maxMs = 12000) {
        const deadline = Date.now() + maxMs;
        while (state.spinning && state.stoppedReels.size < 5 && Date.now() < deadline) {
            await delay(32);
        }
    }

    async function stopRemainingReels(options = {}) {
        if (!state.spinning) return;
        if (options.markStopAll) {
            if (!playerStopArmed()) return;
            state.stopAllUsed = true;
            state.skillStopSatisfied = true;
        }
        if (state.autoStopping) return;
        state.autoStopping = true;
        clearStopTimers();
        setStopCountdownActive(false);
        updateSpinButton();
        $$('.verga-stop-btn').forEach((btn) => {
            btn.disabled = true;
            btn.classList.remove('is-counting');
        });
        const remaining = [0, 1, 2, 3, 4].filter((reelIndex) => !state.stoppedReels.has(reelIndex));
        const source = options.markStopAll ? 'player_all' : 'auto';
        remaining.forEach((reelIndex) => {
            freezeReelOnStop(reelIndex, source);
        });
        remaining.forEach((reelIndex) => {
            const reelNode = $(`.boss-crown-reel[data-reel="${reelIndex}"]`);
            if (reelNode?.classList.contains('is-spinning')) {
                stopStripScroll(reelNode);
            }
        });
        const netStops = window.IqwinSkillSpin && remaining.length
            ? window.IqwinSkillSpin.takeStops(
                state,
                remaining,
                source,
                (reelIndex) => getMechanicalReelStrip(reelIndex).length
            )
            : Promise.resolve({});
        await Promise.all(remaining.map((reelIndex) => (
            revealingReels.has(reelIndex) || state.stoppedReels.has(reelIndex)
                ? waitForReelStopped(reelIndex)
                : revealReel(reelIndex, true, true)
        )));
        const map = await netStops;
        remaining.forEach((reelIndex) => {
            if (Number.isFinite(Number(state.roundStopIndexes[reelIndex]))) return;
            if (map && map[reelIndex] !== undefined) {
                state.roundStopIndexes[reelIndex] = map[reelIndex];
            }
        });
        await waitForAllReelsStopped();
        if (state.stoppedReels.size >= 5 && !state.finishingRound) {
            await onAllReelsStopped();
        }
    }

    async function autoStopAllReels() {
        await stopRemainingReels();
    }

    async function stopAllReelsManual() {
        await stopRemainingReels({ markStopAll: true });
    }

    function markStopButtonUsed(btn) {
        if (!btn) return;
        btn.classList.remove('is-counting');
        btn.classList.add('is-stopped');
        btn.disabled = true;
        const seconds = btn.querySelector('.verga-stop-seconds');
        if (seconds) seconds.setAttribute('aria-hidden', 'true');
    }

    function applySpinButtonState(btn) {
        if (!btn) return;

        const spinBlocked = state.spinning;
        const bigWinBlocked = window.IqwinTerminalSpinWinOverlay && window.IqwinTerminalSpinWinOverlay.isBigWinActive();
        const contestBlocked = window.IqwinContestMode && typeof window.IqwinContestMode.isSpinBlocked === 'function'
            && window.IqwinContestMode.isSpinBlocked();
        const spinVisibility = window.IqwinTerminalSpinButtonVisibility;
        const hideAfterManualReelStop = spinVisibility && spinVisibility.shouldHideDuringSpin(state);

        if (hideAfterManualReelStop) {
            btn.classList.remove('is-stop-all', 'is-play-stop-mode');
            btn.disabled = true;
            spinVisibility.setHidden(btn, true);
            return;
        }

        if (spinVisibility) spinVisibility.setHidden(btn, false);

        const canStopAll = state.sessionReady
            && playerStopArmed()
            && state.manualStopReels.size === 0
            && !state.autoStopping
            && state.stoppedReels.size < 5;

        btn.classList.toggle('is-play-stop-mode', state.playStopMode && !spinBlocked);

        if (state.playStopMode) {
            const canStopAllDuringSpin = state.spinning
                && state.sessionReady
                && playerStopArmed()
                && state.manualStopReels.size === 0
                && !state.autoStopping
                && state.stoppedReels.size < 5;
            if (canStopAllDuringSpin) {
                btn.classList.add('is-stop-all');
                btn.disabled = bigWinBlocked || contestBlocked;
                btn.setAttribute('aria-label', 'Opreste toate');
                return;
            }
            btn.classList.remove('is-stop-all');
            btn.disabled = spinBlocked || bigWinBlocked || contestBlocked;
            btn.setAttribute('aria-label', state.spinning ? 'Se opreste automat' : 'Spin si opreste automat');
            return;
        }

        if (!state.spinning || state.finishingRound) {
            btn.classList.remove('is-stop-all');
            btn.disabled = spinBlocked || bigWinBlocked || contestBlocked;
            btn.setAttribute('aria-label', 'Start');
            return;
        }

        btn.classList.toggle('is-stop-all', canStopAll);
        btn.disabled = !canStopAll || bigWinBlocked || contestBlocked;
        btn.setAttribute('aria-label', canStopAll ? 'Opreste toate' : 'Start');
    }

    function updateSpinButton() {
        applySpinButtonState($('#spinButton'));
        updateSpinModeToggle();
    }

    function scheduleQuickAutoStop() {
        if (timers.quickAutoStop) window.clearTimeout(timers.quickAutoStop);
        const profileDelay = getSpeedProfile().spinAutoStopDelay ?? 480;
        const minArm = window.IqwinSkillSpin && typeof window.IqwinSkillSpin.minPlayerStopMs === 'function'
            ? window.IqwinSkillSpin.minPlayerStopMs(state)
            : profileDelay;
        const delay = Math.max(profileDelay, minArm);
        timers.quickAutoStop = window.setTimeout(() => {
            timers.quickAutoStop = null;
            if (state.spinning && !state.autoStopping && !state.finishingRound) {
                stopAllReelsManual();
            }
        }, delay);
    }

    function setControlsLocked(locked) {
        document.body.classList.toggle('is-boss-crown-spinning', locked);
        updateSpinButton();
        $$('#betBasePrev, #betBaseNext, #betBaseButtons .slot-bet-btn, #lineButtons [data-lines], #terminalVolumeToggle, #terminalVolumeSlider, #terminalSpeedBar, #infoButton').forEach((btn) => {
            btn.disabled = locked;
        });
        if (!locked) {
            document.body.classList.remove('is-stop-arm-locked');
            clearStopTimers();
            setStopCountdownActive(false);
            $$('.verga-stop-btn').forEach((btn) => {
                btn.disabled = true;
                resetStopButtonVisuals(btn);
            });
            updateBetStepperUI();
            updateHalfButton();
        }
    }

    function captureActiveRound() {
        state.activeRound = {
            sessionId: state.sessionId || null,
            gameId: state.gameId,
            betAmount: totalBetAmount(),
        };
    }

    function isContestHalfBetBlocked() {
        return !!(window.IqwinContestMode
            && typeof window.IqwinContestMode.isHalfBetBlocked === 'function'
            && window.IqwinContestMode.isHalfBetBlocked());
    }

    function shouldShowHalfBetOffer(winAmount) {
        if (isContestHalfBetBlocked()) return false;
        const betAmount = Number(state.activeRound?.betAmount || totalBetAmount());
        return winAmount <= 0 && betAmount > 0;
    }

    function finalizeHalfBetOffer(winAmount) {
        if (shouldShowHalfBetOffer(winAmount)) {
            activateHalfBetOffer();
        } else {
            clearHalfBetOffer();
        }
    }

    function consumeHalfBetOffer() {
        state.halfBetOffer = { active: false, sessionId: null, gameId: null, betAmount: 0 };
        updateHalfButton();
    }

    function clearHalfBetOffer({ closeQuiz = true } = {}) {
        state.halfBetOffer = { active: false, sessionId: null, gameId: null, betAmount: 0 };
        updateHalfButton();
        if (closeQuiz && window.MillionaireQuiz) {
            MillionaireQuiz.close();
        }
    }

    function activateHalfBetOffer() {
        if (isContestHalfBetBlocked()) {
            clearHalfBetOffer({ closeQuiz: true });
            return;
        }
        const round = state.activeRound;
        const betAmount = Math.max(0, Number(round?.betAmount || totalBetAmount()));
        if (betAmount <= 0) {
            clearHalfBetOffer({ closeQuiz: false });
            return;
        }
        state.halfBetOffer = {
            active: true,
            sessionId: round?.sessionId ?? state.sessionId ?? null,
            gameId: round?.gameId ?? state.gameId,
            betAmount,
        };
        updateHalfButton();
    }

    function updateHalfButton() {
        const btn = $('#halfButton');
        if (!btn) return;
        if (isContestHalfBetBlocked()) {
            btn.classList.add('is-hidden');
            btn.classList.remove('is-half-ready', 'is-half-pending');
            btn.disabled = true;
            return;
        }
        const ready = Boolean(state.halfBetOffer?.active) && !state.spinning;
        btn.classList.toggle('is-hidden', !ready);
        btn.disabled = !ready;
        btn.classList.toggle('is-half-ready', ready);
    }

    function updateBalance() {
        if (window.IqwinTerminalCreditsDisplay) {
            IqwinTerminalCreditsDisplay.updateBalance(state.credits);
            return;
        }
        const node = $('#balanceValue');
        if (node) node.textContent = formatBalanceNumber(toDisplayCredits(state.credits));
    }

    function notifyParentCredits() {
        if (window.parent && window.parent !== window) {
            window.parent.postMessage({ type: 'skill-game-credits', credits: state.credits }, '*');
        }
    }

    function updateBetLabel(options = {}) {
        const node = $('#betLabel');
        if (node) node.classList.remove('is-skill-forfeit');
        if (state.spinning) {
            if (node) node.textContent = 'STOP pe toate cele 5 role sau apasa Opreste toate';
            if (!options.preserveStatusHint && window.IqwinTerminalStatusHint) {
                window.IqwinTerminalStatusHint.setSpinning();
            }
            return;
        }
        if (!options.preserveStatusHint && window.IqwinTerminalStatusHint) {
            window.IqwinTerminalStatusHint.setIdle();
        }
        if (!node) return;
        const lineLabel = state.lines === 1 ? 'linie' : 'linii';
        const displayBet = toDisplayCredits(state.bet);
        const displayTotal = toDisplayCredits(totalBetAmount());
        node.textContent = `${formatBetNumber(displayBet)} valoare/linie x ${state.lines} ${lineLabel} = ${formatBetNumber(displayTotal)} — apasa START`;
    }

    function showMessage(text, keep = false, options = {}) {
        if (options.forfeit && window.IqwinTerminalStatusHint) {
            window.IqwinTerminalStatusHint.setForfeit();
            return;
        }
        if (text && !state.spinning && window.IqwinTerminalStatusHint) {
            window.IqwinTerminalStatusHint.setMessage(text, options);
        }
        const node = $('#betLabel');
        if (!node || !text || state.spinning) {
            return;
        }
        node.textContent = text;
        node.classList.toggle('is-skill-forfeit', Boolean(options.forfeit));
        if (!keep) {
            window.setTimeout(() => {
                if (node.textContent === text && !state.spinning) {
                    updateBetLabel();
                }
            }, 2200);
        }
    }

    function resetSkillStopTracking() {
        state.manualStopReels.clear();
        state.stopAllUsed = false;
        state.skillStopSatisfied = false;
    }

    function markManualStopReel(reelIndex) {
        state.manualStopReels.add(reelIndex);
        if (state.manualStopReels.size >= 5) {
            state.skillStopSatisfied = true;
        }
        const spinVisibility = window.IqwinTerminalSpinButtonVisibility;
        if (spinVisibility && state.spinning) {
            const btn = $('#spinButton');
            btn.classList.remove('is-stop-all', 'is-play-stop-mode');
            btn.disabled = true;
            spinVisibility.setHidden(btn, true);
        }
    }

    function isSkillStopSatisfied() {
        return state.skillStopSatisfied || state.stopAllUsed || state.manualStopReels.size >= 5;
    }

    function randomizeVisibleBoard() {
        $$('.boss-crown-reel').forEach((reel) => {
            const reelIndex = Number(reel.dataset.reel || 0);
            const column = randomReelColumn(reelIndex);
            reel.querySelectorAll('.boss-crown-cell').forEach((cell, row) => {
                setCellSymbol(cell, column[row] || symbolKeys[0]);
            });
        });
    }

    function scatterPositions(board) {
        const positions = [];
        board.forEach((column, reel) => {
            if (!SCATTER_REEL_INDEXES.has(reel)) return;
            column.forEach((symbol, row) => {
                if (symbol === 'scatter') positions.push(`${reel}-${row}`);
            });
        });
        return positions;
    }

    function totalBetAmount() {
        const lineHundredths = Math.round(state.bet * 100);
        const totalHundredths = lineHundredths * state.lines;
        return roundBet(totalHundredths / 100);
    }

    function totalBetForBase(basePerLine) {
        const lineHundredths = Math.round(roundBet(basePerLine) * 100);
        const totalHundredths = lineHundredths * state.lines;
        return roundBet(totalHundredths / 100);
    }

    function isWildSymbol(symbol) {
        return symbol === 'scatter';
    }

    function isIqwinSymbol(symbol) {
        return IQWIN_SYMBOLS.has(symbol);
    }

    function canWildSubstituteForTarget(target) {
        return target !== null && !isIqwinSymbol(target);
    }

    function countPaylineMatches(symbols) {
        let target = null;
        let matched = 0;
        let pendingWilds = 0;

        for (const symbol of symbols) {
            if (isWildSymbol(symbol)) {
                if (target === null) {
                    pendingWilds += 1;
                } else if (canWildSubstituteForTarget(target)) {
                    matched += 1;
                } else {
                    break;
                }
                continue;
            }

            const normalized = normalizeMatchSymbol(symbol);
            if (target === null) {
                target = normalized;
                matched = isIqwinSymbol(target) ? 1 : pendingWilds + 1;
                pendingWilds = 0;
                continue;
            }

            if (symbolsMatch(symbol, target)) {
                matched += 1;
                continue;
            }
            break;
        }

        return { target, matched };
    }

    function normalizeMatchSymbol(symbol) {
        return symbol;
    }

    function symbolsMatch(left, right) {
        return normalizeMatchSymbol(left) === normalizeMatchSymbol(right);
    }

    function evaluateIqwinLine(board, lineRows) {
        for (let reel = 0; reel < 5; reel += 1) {
            if (board[reel][lineRows[reel]] !== IQWIN_LINE_SEQUENCE[reel]) {
                return null;
            }
        }

        const payout = calcWinPayout(IQWIN_LINE_PAY);
        if (payout <= 0) {
            return null;
        }

        return {
            symbol: 'iqwin',
            count: 5,
            payout,
            positions: lineRows.map((row, reel) => `${reel}-${row}`)
        };
    }

    function evaluatePayline(board, lineRows) {
        const iqwinWin = evaluateIqwinLine(board, lineRows);
        if (iqwinWin) {
            return iqwinWin;
        }

        const symbols = [];
        for (let reel = 0; reel < 5; reel += 1) {
            symbols.push(board[reel][lineRows[reel]]);
        }

        const { target, matched } = countPaylineMatches(symbols);

        if (!target || matched < 3 || isIqwinSymbol(target)) {
            return null;
        }

        let payout = 0;
        if (target === 'dollar') {
            const multiplier = DOLLAR_TOTAL_BET_PAY[matched];
            if (!multiplier) return null;
            payout = calcTotalBetPayout(multiplier);
        } else {
            const payKey = paytable[target] ? target : 'q';
            const multiplier = paytable[payKey]?.[matched];
            if (!multiplier) return null;
            payout = calcWinPayout(multiplier);
        }
        if (payout <= 0) return null;

        return {
            symbol: target,
            count: matched,
            payout,
            positions: lineRows.slice(0, matched).map((row, reel) => `${reel}-${row}`)
        };
    }

    function evaluateBoard(board) {
        const wins = [];
        let total = 0;

        activePaylines().forEach((lineRows, index) => {
            const lineWin = evaluatePayline(board, lineRows);
            if (!lineWin) return;
            total += lineWin.payout;
            wins.push({
                line: index + 1,
                symbol: lineWin.symbol,
                count: lineWin.count,
                payout: lineWin.payout,
                positions: lineWin.positions
            });
        });

        const scatters = scatterPositions(board);
        if (scatters.length >= 3) {
            const scatterCount = Math.min(5, scatters.length);
            const multiplier = paytable.scatter[scatterCount] || 0;
            const payout = calcWinPayout(multiplier);
            if (payout > 0) {
                total += payout;
                wins.push({
                    line: 0,
                    symbol: 'scatter',
                    count: scatters.length,
                    payout,
                    positions: scatters
                });
            }
        }

        return { wins, total: roundBet(total) };
    }

    function resetWinVisuals() {
        $$('.boss-crown-cell.is-winning, .boss-crown-cell.is-line-symbol-active, .boss-crown-cell.is-line-symbol-loop').forEach((cell) => {
            cell.classList.remove('is-winning', 'is-line-symbol-active', 'is-line-symbol-loop');
            cell.style.removeProperty('--boss-crown-line-color');
            cell.style.removeProperty('--boss-crown-line-soft');
            cell.style.removeProperty('--boss-crown-line-glow');
            const img = cell.querySelector('img');
            if (img) {
                img.style.animation = 'none';
                void img.offsetWidth;
                img.style.removeProperty('animation');
            }
            void cell.offsetWidth;
        });
        const overlay = $('#paylineOverlay');
        if (overlay) {
            overlay.replaceChildren();
            overlay.style.visibility = 'hidden';
            void overlay.offsetWidth;
            overlay.style.removeProperty('visibility');
        }
    }

    function clearWinHighlights() {
        state.winCycleId += 1;
        resetWinVisuals();
    }

    function clearScatterPulseTimers() {
        state.scatterPulseTimers.forEach((timer) => window.clearTimeout(timer));
        state.scatterPulseTimers = [];
    }

    function clearIqwinPulseTimers() {
        state.iqwinPulseTimers.forEach((timer) => window.clearTimeout(timer));
        state.iqwinPulseTimers = [];
    }

    function clearIqwinReveals() {
        clearIqwinPulseTimers();
        $$('.boss-crown-cell.is-iqwin-reveal').forEach((cell) => {
            cell.classList.remove(
                'is-iqwin-reveal',
                'is-iqwin-i',
                'is-iqwin-q',
                'is-iqwin-w',
                'is-iqwin-n',
                'is-iqwin-chain',
                'is-iqwin-pulse'
            );
        });
    }

    function animateIqwinLetter(cell, symbol, chainBoost = false) {
        if (!cell || !IQWIN_SYMBOLS.has(symbol)) return;

        const variantClass = IQWIN_REVEAL_CLASS[symbol];
        cell.classList.remove(
            'is-iqwin-reveal',
            'is-iqwin-i',
            'is-iqwin-q',
            'is-iqwin-w',
            'is-iqwin-n',
            'is-iqwin-chain',
            'is-iqwin-pulse'
        );
        void cell.offsetWidth;
        cell.classList.add('is-iqwin-reveal', variantClass);
        if (chainBoost) {
            cell.classList.add('is-iqwin-chain');
        }

        requestAnimationFrame(() => {
            if (!cell.isConnected) return;
            cell.classList.remove('is-iqwin-pulse');
            void cell.offsetWidth;
            cell.classList.add('is-iqwin-pulse');
        });

        const pulse = () => {
            if (!cell.isConnected || !cell.classList.contains('is-iqwin-reveal')) return;
            cell.classList.remove('is-iqwin-pulse');
            void cell.offsetWidth;
            cell.classList.add('is-iqwin-pulse');
            state.iqwinPulseTimers.push(window.setTimeout(pulse, chainBoost ? 1900 : 2400));
        };
        state.iqwinPulseTimers.push(window.setTimeout(pulse, chainBoost ? 1350 : 1550));
    }

    function revealIqwinLettersOnReel(reelIndex, column) {
        const expected = IQWIN_LINE_SEQUENCE[reelIndex];
        const isChainStep = iqwinSoundChain >= 0
            && reelIndex === iqwinSoundChain
            && expected
            && column.includes(expected);

        column.forEach((symbol, row) => {
            if (!IQWIN_SYMBOLS.has(symbol)) return;
            const cell = $(`[data-position="${reelIndex}-${row}"]`);
            if (!cell) return;
            animateIqwinLetter(cell, symbol, isChainStep && symbol === expected);
        });
    }

    function clearScatterPulses() {
        clearScatterPulseTimers();
        $$('.boss-crown-cell img[data-symbol="scatter"], .boss-crown-cell img[data-symbol="dollar"]').forEach((image) => {
            image.closest('.boss-crown-cell')?.classList.remove(
                'is-special-reveal',
                'is-dollar-reveal',
                'is-star-reveal',
                'is-scatter-anticipation-pulse'
            );
        });
    }

    function scatterPulseDelay(cell) {
        return cell.classList.contains('is-scatter-anticipation-pulse') ? 900 : 1850;
    }

    function animateSpecialSymbol(cell, type, loop = false) {
        if (!cell) return;
        cell.classList.remove('is-special-reveal', 'is-dollar-reveal', 'is-star-reveal');
        void cell.offsetWidth;
        cell.classList.add('is-special-reveal', 'is-dollar-reveal');
        if (type === 'scatter') {
            if (!loop) {
                window.setTimeout(() => {
                    cell.classList.remove('is-special-reveal', 'is-dollar-reveal', 'is-star-reveal');
                }, 1180);
                return;
            }
            const pulseScatter = () => {
                if (!cell.isConnected || cell.querySelector('img')?.dataset.symbol !== 'scatter') return;
                cell.classList.remove('is-special-reveal', 'is-dollar-reveal', 'is-star-reveal');
                void cell.offsetWidth;
                cell.classList.add('is-special-reveal', 'is-dollar-reveal');
                state.scatterPulseTimers.push(window.setTimeout(pulseScatter, scatterPulseDelay(cell)));
            };
            state.scatterPulseTimers.push(window.setTimeout(pulseScatter, scatterPulseDelay(cell)));
            return;
        }
        window.setTimeout(() => {
            cell.classList.remove('is-special-reveal', 'is-dollar-reveal', 'is-star-reveal');
        }, 1180);
    }

    function revealScatterOnReel(reelIndex, column) {
        if (column.includes('scatter')) {
            playSampleSound('bong');
        }
    }

    function getLineColor(line, fallbackIndex = 0) {
        const lineNumber = Number(line?.line || 0);
        const index = lineNumber > 0 ? lineNumber - 1 : fallbackIndex;
        return lineColors[((index % lineColors.length) + lineColors.length) % lineColors.length];
    }

    function markWins(positions, color) {
        positions.forEach((position) => {
            const cell = $(`[data-position="${position}"]`);
            if (!cell) return;
            cell.style.setProperty('--boss-crown-line-color', color.main);
            cell.style.setProperty('--boss-crown-line-soft', color.soft);
            cell.style.setProperty('--boss-crown-line-glow', color.glow);
            cell.classList.add('is-winning');
        });
    }

    function renderWinPaylineOverlay(wins) {
        const overlay = $('#paylineOverlay');
        if (!overlay) return;

        const draw = () => {
            const overlayRect = overlay.getBoundingClientRect();
            if (!overlayRect.width || !overlayRect.height) {
                overlay.innerHTML = '';
                return;
            }

            overlay.setAttribute('viewBox', `0 0 ${overlayRect.width} ${overlayRect.height}`);
            overlay.innerHTML = wins.map((win, index) => {
                if (!win.line || !win.count) return '';
                const linePattern = paylines[win.line - 1];
                if (!linePattern) return '';
                const color = getLineColor(win, index);
                const delay = `${Math.min(index * 0.14, 0.56).toFixed(2)}s`;
                const style = `--boss-crown-line-color:${color.main};--boss-crown-line-soft:${color.soft};--boss-crown-line-glow:${color.glow};--boss-crown-line-core:${color.core};animation-delay:${delay}`;
                const cells = [];

                for (let reel = 0; reel < win.count; reel += 1) {
                    const row = linePattern[reel];
                    const cell = $(`.verga-reels-panel [data-position="${reel}-${row}"]`);
                    if (!cell) continue;
                    const rect = cell.getBoundingClientRect();
                    cells.push({
                        x: rect.left - overlayRect.left + rect.width / 2,
                        y: rect.top - overlayRect.top + rect.height / 2
                    });
                }

                if (cells.length < 2) return '';

                return cells.slice(0, -1).map((start, segmentIndex) => {
                    const end = cells[segmentIndex + 1];
                    const path = `M ${start.x.toFixed(1)} ${start.y.toFixed(1)} L ${end.x.toFixed(1)} ${end.y.toFixed(1)}`;
                    return `<path class="boss-crown-payline-glow" d="${path}" style="${style}"></path><path class="boss-crown-payline-core" d="${path}" style="${style}"></path>`;
                }).join('');
            }).join('');
        };

        window.requestAnimationFrame(() => {
            window.requestAnimationFrame(draw);
        });
    }

    function showActiveWinLine(win, index = 0, options = {}) {
        resetWinVisuals();
        const color = getLineColor(win, index);
        win.positions.forEach((position) => {
            const cell = $(`[data-position="${position}"]`);
            if (!cell) return;
            cell.style.setProperty('--boss-crown-line-color', color.main);
            cell.style.setProperty('--boss-crown-line-soft', color.soft);
            cell.style.setProperty('--boss-crown-line-glow', color.glow);
            cell.classList.add('is-line-symbol-active');
            cell.classList.toggle('is-line-symbol-loop', Boolean(options.loopSymbols));
        });
        renderWinPaylineOverlay([win]);
    }

    function showLineSymbolAnimation(win, index = 0) {
        resetWinVisuals();
        const color = getLineColor(win, index);
        win.positions.forEach((position) => {
            const cell = $(`[data-position="${position}"]`);
            if (!cell) return;
            cell.style.setProperty('--boss-crown-line-color', color.main);
            cell.style.setProperty('--boss-crown-line-soft', color.soft);
            cell.style.setProperty('--boss-crown-line-glow', color.glow);
            cell.classList.add('is-line-symbol-active');
        });
    }

    async function playWinCycle(wins) {
        const cycleId = ++state.winCycleId;
        const isCurrentCycle = () => state.winCycleId === cycleId;
        const speedProfile = getSpeedProfile();
        const payableLines = wins.filter((win) => win.line > 0 && win.payout > 0 && win.positions.length >= 2);
        const scatterWins = wins.filter((win) => win.line === 0);
        const lineShowDuration = 1000;

        if (!payableLines.length) {
            if (scatterWins.length) {
                const positions = scatterWins.flatMap((win) => win.positions);
                markWins(positions, lineColors[0]);
                await delay(speedProfile.winScatterHold);
            }
            return;
        }

        if (hasLineWinSound(payableLines)) {
            playSampleSound('linewin');
        }

        while (isCurrentCycle()) {
            for (let index = 0; index < payableLines.length; index += 1) {
                if (!isCurrentCycle()) return;
                showActiveWinLine(payableLines[index], index, { loopSymbols: true });
                await delay(lineShowDuration);
                if (!isCurrentCycle()) return;
                resetWinVisuals();
            }
        }
    }

    function renderPaylines(wins) {
        renderWinPaylineOverlay(wins);
    }

    function hasTerminalServer() {
        return Boolean(
            localStorage.getItem('skill_terminal_credentials')
            && localStorage.getItem('skill_terminal_server')
        );
    }

    function terminalRoundSyncOptions() {
        return {
            gameId: state.gameId,
            formatDisplayAmount: (value) => formatBalanceNumber(toDisplayCredits(value)),
            onBalance: (balance) => {
                state.credits = Number(balance);
                updateBalance();
                notifyParentCredits();
            },
            onLastWin: (amount) => {
                const node = $('#lastWinValue');
                if (node && window.IqwinTerminalRoundSync) {
                    IqwinTerminalRoundSync.renderLastWin(node, amount, (value) => formatBalanceNumber(toDisplayCredits(value)), {});
                }
            },
            onWinRecovered: (amount) => {
                const node = $('#lastWinValue');
                if (node && window.IqwinTerminalRoundSync) {
                    IqwinTerminalRoundSync.renderLastWin(node, amount, (value) => formatBalanceNumber(toDisplayCredits(value)), {});
                }
                if (window.IqwinTerminalSpinWinOverlay && amount > 0) {
                    window.IqwinTerminalSpinWinOverlay.show(amount, {
                        formatted: formatBalanceNumber(toDisplayCredits(amount)),
                        forfeit: false,
                        skillStopUsed: true,
                        allowBigWin: true,
                        betAmount: totalBetAmount(),
                        soundEnabled: state.soundEnabled,
                        soundVolume: getSoundVolumeMultiplier()
                    });
                }
            },
            onProcessingMessage: (text) => {
                showMessage(text || '');
            }
        };
    }

    async function flushPendingRoundSync() {
        if (!hasTerminalServer() || !window.IqwinTerminalRoundSync) {
            return { ready: true, credited: 0 };
        }
        return IqwinTerminalRoundSync.prepareForNewSpin({
            ...terminalRoundSyncOptions(),
            loadCredits
        });
    }

    async function loadCredits() {
        try {
            const storage = localStorage.getItem('skill_terminal_credentials');
            const server = localStorage.getItem('skill_terminal_server');
            if (!storage || !server) {
                state.credits = 100;
                updateBalance();
                return;
            }
            const credentials = JSON.parse(storage);
            const base = server.replace(/\/$/, '') + '/api/terminal';
            const response = await fetch(base + '/bootstrap.php', {
                headers: {
                    'X-Terminal-Code': credentials.terminal_code,
                    'X-Terminal-Secret': credentials.api_secret
                }
            });
            const data = await response.json();
            if (data.ok && data.terminal) {
                state.credits = Number(data.terminal.credits_balance || 0);
                if (window.IqwinTerminalCreditsDisplay) {
                    IqwinTerminalCreditsDisplay.setCreditRate(data.terminal.credit_rate);
                }
            }
        } catch (error) {
            state.credits = 100;
        }
        updateBalance();
    }

    async function revealReel(reelIndex, fromAuto = false, skipNetwork = false) {
        if (revealingReels.has(reelIndex)) return;
        const reelNode = $(`.boss-crown-reel[data-reel="${reelIndex}"]`);
        if (!reelNode || !state.roundBoard || state.stoppedReels.has(reelIndex)) return;
        if (!fromAuto && state.autoStopping) return;

        revealingReels.add(reelIndex);
        const stopBtn = $(`.verga-stop-btn[data-reel="${reelIndex}"]`);
        if (!fromAuto) {
            markStopButtonUsed(stopBtn);
        } else if (stopBtn) {
            markStopButtonUsed(stopBtn);
        }
        updateSpinButton();
        try {
            const source = fromAuto ? (state.stopAllUsed ? 'player_all' : 'auto') : 'player';
            const frozenColumn = Array.isArray(state.roundBoard?.[reelIndex])
                && state.roundBoard[reelIndex].length === 3
                && state.roundBoard[reelIndex].every((symbol) => Boolean(symbol))
                ? state.roundBoard[reelIndex].slice()
                : null;
            if (!frozenColumn && !Number.isFinite(Number(state.roundStopIndexes[reelIndex])) && window.IqwinSkillSpin) {
                const elapsed = window.IqwinSkillSpin.captureElapsed(state, source);
                window.IqwinSkillSpin.rememberClickElapsed(state, [reelIndex], elapsed);
                state.roundStopIndexes[reelIndex] = window.IqwinSkillSpin.localStopIndex(
                    state,
                    reelIndex,
                    source,
                    getMechanicalReelStrip(reelIndex).length,
                    elapsed
                );
            }
            let takePromise = Promise.resolve(null);
            if (!skipNetwork && window.IqwinSkillSpin && (state.serverStops?.[reelIndex] === null || state.serverStops?.[reelIndex] === undefined)) {
                takePromise = window.IqwinSkillSpin.takeStops(
                    state,
                    [reelIndex],
                    source,
                    (index) => getMechanicalReelStrip(index).length
                );
            }
            const physicsStop = state.roundStopIndexes[reelIndex];
            let column = frozenColumn;
            if (!column && Number.isFinite(physicsStop)) {
                const lockedStop = Number(physicsStop);
                const visible = readVisibleStripColumn(reelNode, reelIndex);
                column = visible?.column || readMechanicalColumn(reelIndex, normalizeStopIndex(reelIndex, lockedStop));
                state.roundStopIndexes[reelIndex] = normalizeStopIndex(reelIndex, visible?.stopIndex ?? lockedStop);
            } else if (!column) {
                await settleReelToNearestRow(reelNode, fromAuto ? 'auto' : 'manual');
                const settled = readSettledColumnFromStrip(reelNode, reelIndex);
                column = settled?.column || null;
                let resolvedStopIndex = settled?.stopIndex ?? null;
                if (!column) {
                    const stopIndex = readReelStopIndex(reelNode, reelIndex);
                    column = stopIndex !== null
                        ? readMechanicalColumn(reelIndex, stopIndex)
                        : readReelOutcomeFromStrip(reelNode, reelIndex);
                    resolvedStopIndex = stopIndex;
                    if (resolvedStopIndex === null) {
                        resolvedStopIndex = findStopIndexForColumn(reelIndex, column);
                    }
                }
                if (resolvedStopIndex !== null) {
                    state.roundStopIndexes[reelIndex] = normalizeStopIndex(reelIndex, resolvedStopIndex);
                }
            }
            if (!state.roundBoard) state.roundBoard = createEmptyRoundBoard();
            state.roundBoard[reelIndex] = column ? column.slice() : null;

            if (!column) {
                return;
            }

            column.forEach((symbol, row) => {
                const cell = $(`[data-position="${reelIndex}-${row}"]`);
                if (cell) setCellSymbol(cell, symbol);
            });

            await new Promise((resolve) => requestAnimationFrame(resolve));
            removeSpinStrip(reelNode);
            reelNode.classList.remove('is-spinning', 'is-reel-settling', 'is-reel-freezing');

            checkIqwinReelSound(reelIndex, column);
            revealIqwinLettersOnReel(reelIndex, column);

            state.stoppedReels.add(reelIndex);
            updateSpinButton();
            if (column.includes('scatter')) {
                revealScatterOnReel(reelIndex, column);
            } else {
                playGameSound('stop');
            }
            const map = await takePromise;
            if (map && map[reelIndex] !== undefined && !Number.isFinite(Number(state.roundStopIndexes[reelIndex]))) {
                state.roundStopIndexes[reelIndex] = Number(map[reelIndex]);
            }
        } finally {
            revealingReels.delete(reelIndex);
        }
    }

    async function finishRound(result) {
        const roundBetAmount = totalBetAmount();
        const winAmount = result.total;
        const reelStops = state.roundStopIndexes.slice();
        const serverLinked = hasTerminalServer();
        const skillStopUsed = (typeof state.serverSkillStopUsed === 'boolean')
            ? state.serverSkillStopUsed
            : (state.skillStopSatisfied || isSkillStopSatisfied());
        const forfeitWin = winAmount > 0 && !skillStopUsed;
        const lastWinNode = $('#lastWinValue');

        let creditedWin = forfeitWin ? 0 : winAmount;
        let overlayWin = 0;
        let settlement = null;

        if (winAmount > 0) {
            if (!serverLinked) {
                if (!hasLineWinSound(result.wins)) {
                    playGameSound('win');
                }
            }
            if (!serverLinked && creditedWin > 0) {
                state.credits += creditedWin;
                if (lastWinNode) {
                    lastWinNode.textContent = formatBalanceNumber(toDisplayCredits(creditedWin));
                    lastWinNode.classList.remove('is-forfeited');
                }
            }
        } else {
            if (lastWinNode) {
                lastWinNode.textContent = formatBalanceNumber(0);
                lastWinNode.classList.remove('is-forfeited');
            }
            clearWinHighlights();
        }

        if (!serverLinked) {
            updateBalance();
        }

        if (serverLinked) {
            settlement = await IqwinTerminalRoundSync.settleRound({
                gameId: state.gameId,
                getSessionId: () => state.sessionId,
                setSessionId: (id) => { state.sessionId = id; },
                reelStops,
                winAmount,
                creditedWin,
                skillStopUsed,
                forfeitWin,
                lastWinNode,
                formatDisplayAmount: (value) => formatBalanceNumber(toDisplayCredits(value)),
                onBalance: (balance) => {
                    state.credits = Number(balance);
                    updateBalance();
                    notifyParentCredits();
                },
                showMessage,
                loadCredits,
                onWinRecovered: terminalRoundSyncOptions().onWinRecovered
            });
            creditedWin = settlement.creditedWin;
            if (settlement.syncOk && creditedWin > 0 && winAmount > 0) {
                overlayWin = creditedWin;
            }
            finalizeHalfBetOffer(winAmount);
        } else if (creditedWin > 0) {
            overlayWin = creditedWin;
        }

        if (winAmount > 0) {
            if (!serverLinked) {
                clearHalfBetOffer();
            }
        } else if (!serverLinked) {
            finalizeHalfBetOffer(winAmount);
        }

        state.spinning = false;
        state.autoStopAfterStart = false;
        state.autoStopping = false;
        state.finishingRound = false;
        state.sessionReady = true;
        resetSkillStopTracking();
        if (Array.isArray(state.roundStopIndexes) && state.roundStopIndexes.every((value) => value !== null)) {
            if (window.IqwinSkillSpin) {
                window.IqwinSkillSpin.rememberSettledStops(state, state.roundStopIndexes);
            } else {
                state.lastSettledStops = state.roundStopIndexes.slice();
            }
        }
        state.roundBoard = null;
        state.roundStopIndexes = [null, null, null, null, null];
        state.stoppedReels.clear();
        state.resolvedScatterCount = 0;
        clearScatterPulses();
        clearIqwinReveals();
        clearStopTimers();
        setControlsLocked(false);
        updateSpinButton();
        if (forfeitWin) {
            showMessage('', true, { forfeit: true });
        }
        updateBetLabel({ preserveStatusHint: forfeitWin });

        if (!serverLinked && winAmount <= 0) {
            finalizeHalfBetOffer(winAmount);
        }


        if (overlayWin > 0) {
            if (serverLinked && settlement?.syncOk) {
                if (!hasLineWinSound(result.wins)) {
                    playGameSound('win');
                }
            }
            if (window.IqwinTerminalSpinWinOverlay) {
                window.IqwinTerminalSpinWinOverlay.show(overlayWin, {
                    formatted: formatBalanceNumber(toDisplayCredits(overlayWin)),
                    forfeit: false,
                    skillStopUsed: skillStopUsed,
                    allowBigWin: skillStopUsed,
                    betAmount: roundBetAmount,
                    soundEnabled: state.soundEnabled,
                    soundVolume: getSoundVolumeMultiplier()
                });
            }
            void playWinCycle(result.wins);
        } else if (forfeitWin && result.total > 0) {
            void playWinCycle(result.wins);
        }
    }

    async function onAllReelsStopped() {
        if (state.finishingRound) return;
        state.finishingRound = true;

        await new Promise((resolve) => requestAnimationFrame(resolve));
        await new Promise((resolve) => requestAnimationFrame(resolve));

        finalizeRoundState();

        const visibleBoard = readBoardFromVisibleCells();
        if (visibleBoard) {
            state.roundBoard = visibleBoard.map((column) => column.slice());
        }

        if (!state.roundBoard || !hasCompleteRoundStops()) {
            state.finishingRound = false;
            state.spinning = false;
            state.autoStopping = false;
            clearStopTimers();
            setControlsLocked(false);
            updateSpinButton();
            showMessage('Eroare sincronizare runda.');
            return;
        }

        const board = (readBoardFromVisibleCells() || state.roundBoard).map((column) => column.slice());
        const result = evaluateBoard(board);
        state.skillStopSatisfied = state.skillStopSatisfied || isSkillStopSatisfied();
        await finishRound(result);
    }

    async function startNewSession() {
        try {
            const storage = localStorage.getItem('skill_terminal_credentials');
            const server = localStorage.getItem('skill_terminal_server');
            if (!storage || !server) return true;
            const credentials = JSON.parse(storage);
            const base = server.replace(/\/$/, '') + '/api/terminal';
            const response = await fetch(base + '/session.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Terminal-Code': credentials.terminal_code,
                    'X-Terminal-Secret': credentials.api_secret
                },
                body: JSON.stringify(
                    window.IqwinContestMode && typeof window.IqwinContestMode.buildStartSessionBody === 'function'
                        ? window.IqwinContestMode.buildStartSessionBody({
                            action: 'start',
                            game_id: state.gameId,
                            bet: state.bet,
                            lines: state.lines,
                            speed_profile: state.speed || 'normal',
                            play_stop_mode: !!state.playStopMode
                        })
                        : {
                            action: 'start',
                            game_id: state.gameId,
                            bet: state.bet,
                            lines: state.lines,
                            speed_profile: state.speed || 'normal',
                            play_stop_mode: !!state.playStopMode
                        }
                )
            });
            let data = await response.json();
            if (!data.ok && data.code === 'open_session' && window.IqwinTerminalRoundSync) {
                await IqwinTerminalRoundSync.handleOpenSessionConflict(terminalRoundSyncOptions(), data.open_session_id);
                const retryResponse = await fetch(base + '/session.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Terminal-Code': credentials.terminal_code,
                        'X-Terminal-Secret': credentials.api_secret
                    },
                    body: JSON.stringify(
                        window.IqwinContestMode && typeof window.IqwinContestMode.buildStartSessionBody === 'function'
                            ? window.IqwinContestMode.buildStartSessionBody({
                                action: 'start',
                                game_id: state.gameId,
                                bet: state.bet,
                                lines: state.lines
                            })
                            : {
                                action: 'start',
                                game_id: state.gameId,
                                bet: state.bet,
                                lines: state.lines
                            }
                    )
                });
                data = await retryResponse.json();
            }
            if (!data.ok) {
                showMessage(data.message || 'Sesiune respinsa.');
                return false;
            }
            state.sessionId = data.session_id;
            if (window.IqwinSkillSpin) {
                window.IqwinSkillSpin.applyStart(state, data);
            }
            if (window.IqwinContestMode && typeof window.IqwinContestMode.syncGameBetFromSession === 'function') {
                window.IqwinContestMode.syncGameBetFromSession(state, data);
            } else if (window.IqwinContestMode && typeof window.IqwinContestMode.lockGameBetState === 'function') {
                window.IqwinContestMode.lockGameBetState(state);
            }
            captureActiveRound();
            if (data.credits_balance !== undefined) {
                state.credits = Number(data.credits_balance);
                updateBalance();
                notifyParentCredits();
            }
            return true;
        } catch (error) {
            showMessage('Eroare pornire sesiune.');
            return false;
        }
    }

    function abortSpinRound() {
        if (!state.spinning) return;
        clearStopTimers();
        state.spinning = false;
        state.sessionReady = true;
        state.autoStopAfterStart = false;
        state.autoStopping = false;
        state.finishingRound = false;
        state.roundBoard = null;
        state.roundStopIndexes = [null, null, null, null, null];
        state.stoppedReels.clear();
        state.resolvedScatterCount = 0;
        clearScatterPulses();
        clearIqwinReveals();
        resetSkillStopTracking();
        resetIqwinSoundChain();
        autoStopChain = Promise.resolve();
        $$('.boss-crown-reel').forEach((reel) => {
            stopStripScroll(reel);
            removeSpinStrip(reel);
            reel.classList.remove('is-spinning', 'is-reel-settling', 'is-reel-freezing');
        });
        $$('.verga-stop-btn').forEach((btn) => {
            btn.disabled = true;
            resetStopButtonVisuals(btn);
        });
        setControlsLocked(false);
        updateSpinButton();
        updateBetLabel();
    }

    function activateSpinControlsAfterSession() {
        if (!state.spinning) return;
        state.sessionReady = true;
        clearStopTimers();
        setStopCountdownActive(false);
        const autoStopAfterStart = state.autoStopAfterStart;
        if (autoStopAfterStart) {
            scheduleQuickAutoStop();
            schedulePlayerStopArm();
        } else {
            startStopCountdown();
        }
        updateSpinButton();
    }

    function beginSpinRound({ waitForSession = false, debitLocalCredits = false } = {}) {
        clearHalfBetOffer();
        state.activeRound = null;
        state.spinning = true;
        document.body.classList.add('is-stop-arm-locked');
        state.sessionReady = !waitForSession;
        const autoStopAfterStart = state.playStopMode;
        state.autoStopAfterStart = autoStopAfterStart;
        state.autoStopping = false;
        state.finishingRound = false;
        resetSkillStopTracking();
        resetIqwinSoundChain();
        autoStopChain = Promise.resolve();
        state.stoppedReels.clear();
        state.resolvedScatterCount = 0;
        state.roundStopIndexes = [null, null, null, null, null];
        state.roundStartStops = (state.lastSettledStops || [0, 0, 0, 0, 0]).slice();
        state.spinLocalT0 = performance.now();
        clearScatterPulses();
        clearIqwinReveals();
        state.roundBoard = createEmptyRoundBoard();
        if (debitLocalCredits) {
            state.credits -= totalBetAmount();
            updateBalance();
            notifyParentCredits();
            captureActiveRound();
        }
        setControlsLocked(true);
        updateBetLabel();
        ensureAudio();
        playGameSound('spin');
        $$('.boss-crown-cell').forEach((cell) => cell.classList.remove('is-winning'));

        $$('.boss-crown-reel').forEach((reel) => {
            reel.classList.add('is-spinning');
            createSpinStrip(reel, Number(reel.dataset.reel || 0));
        });

        if (waitForSession) {
            $$('.verga-stop-btn').forEach((btn) => {
                btn.disabled = true;
                resetStopButtonVisuals(btn);
            });
            setStopCountdownActive(false);
        } else if (autoStopAfterStart) {
            $$('.verga-stop-btn').forEach((btn) => {
                btn.disabled = true;
                resetStopButtonVisuals(btn);
            });
            setStopCountdownActive(false);
            scheduleQuickAutoStop();
        } else {
            startStopCountdown();
        }
        updateSpinButton();
    }

    function startSpin() {
        if (state.spinning || state.finishingRound) return;
        if (!state.stripsReady) {
            showMessage('Se incarca benzile rolei...');
            return;
        }
        if (window.IqwinTerminalSpinWinOverlay && window.IqwinTerminalSpinWinOverlay.isBigWinActive()) return;
        if (window.IqwinTerminalSpinWinOverlay) {
            window.IqwinTerminalSpinWinOverlay.hide();
        }
        clearWinHighlights();
        const betAmount = totalBetAmount();
        const creditCheck = window.IqwinContestMode && typeof window.IqwinContestMode.checkSpinCredits === 'function'
            ? window.IqwinContestMode.checkSpinCredits(betAmount, state.credits)
            : { ok: state.credits >= betAmount, message: 'Disponibil insuficient' };
        if (!creditCheck.ok) {
            showMessage(creditCheck.message || 'Disponibil insuficient');
            return;
        }

        const needsServer = hasTerminalServer();

        const run = async () => {
            if (needsServer) {
                const prepared = await flushPendingRoundSync();
                if (!prepared?.ready) {
                    if (window.IqwinTerminalRoundSync) {
                        IqwinTerminalRoundSync.scheduleBackgroundRetry(terminalRoundSyncOptions());
                    }
                    return;
                }
                beginSpinRound({ waitForSession: true });
            }
            const ok = await startNewSession();
            if (!ok) {
                if (needsServer) abortSpinRound();
                return;
            }
            if (needsServer) {
                activateSpinControlsAfterSession();
                return;
            }
            beginSpinRound({ debitLocalCredits: true });
        };
        void run();
    }

    function handleHalfButtonClick() {
        if (state.spinning || !state.halfBetOffer?.active) return;
        setInfoPopupOpen(false);
        if (window.MillionaireQuiz) {
            MillionaireQuiz.open();
        }
    }

    async function handleSpinButtonClick() {
        if (window.IqwinTerminalSpinWinOverlay && window.IqwinTerminalSpinWinOverlay.isBigWinActive()) return;
        if (state.spinning) {
            if (!state.finishingRound && state.sessionReady && playerStopArmed() && state.manualStopReels.size === 0 && state.stoppedReels.size < 5) {
                clearStopTimers();
                setStopCountdownActive(false);
                state.stopAllUsed = true;
                state.skillStopSatisfied = true;
                if (state.stoppedReels.size < 5) {
                    await stopAllReelsManual();
                } else if (!state.finishingRound) {
                    await onAllReelsStopped();
                }
            }
            return;
        }
        clearWinHighlights();
        startSpin();
    }

    function handleSpinModeToggle(event) {
        event.preventDefault();
        event.stopPropagation();
        if (state.spinning) return;
        state.playStopMode = !state.playStopMode;
        savePlayStopPreference();
        updateSpinModeToggle();
        updateSpinButton();
    }

    function handleStopClick(reelIndex) {
        if (!state.spinning || !state.sessionReady || !playerStopArmed() || state.autoStopping || state.stoppedReels.has(reelIndex)) return;
        if (revealingReels.has(reelIndex)) return;

        markManualStopReel(reelIndex);
        markStopButtonUsed($(`.verga-stop-btn[data-reel="${reelIndex}"]`));
        freezeReelOnStop(reelIndex);
        updateSpinButton();

        void finalizeManualReelStop(reelIndex);
    }

    async function finalizeManualReelStop(reelIndex) {
        try {
            await revealReel(reelIndex);
            if (state.stoppedReels.size >= 5 && !state.finishingRound) {
                clearStopTimers();
                setStopCountdownActive(false);
                await waitForAllReelsSettled();
                state.skillStopSatisfied = state.skillStopSatisfied || isSkillStopSatisfied();
                await onAllReelsStopped();
            }
        } catch (error) {
        }
    }

    function bindKioskGuards() {
        const block = (event) => {
            event.preventDefault();
        };

        document.addEventListener('selectstart', block);
        document.addEventListener('dragstart', block);
        document.addEventListener('contextmenu', block);

        document.addEventListener('mousedown', (event) => {
            if (event.detail > 1) {
                event.preventDefault();
            }
        });
    }

    function bindEvents() {
        initBetButtons();
        $('#spinButton')?.addEventListener('click', handleSpinButtonClick);
        window.addEventListener('iqwin-terminal-big-win-change', updateSpinButton);
        $('#halfButton')?.addEventListener('click', handleHalfButtonClick);
        window.addEventListener('iqwin-contest-block-half-bet', () => {
            clearHalfBetOffer({ closeQuiz: true });
        });

        $$('.verga-stop-btn').forEach((btn) => {
            btn.addEventListener('click', () => {
                handleStopClick(Number(btn.dataset.reel || 0));
            });
        });

        $$('#lineButtons [data-lines]').forEach((btn) => {
            btn.addEventListener('click', () => {
                if (state.spinning) return;
                $$('#lineButtons [data-lines]').forEach((item) => item.classList.remove('is-active'));
                btn.classList.add('is-active');
                state.lines = normalizeLines(btn.dataset.lines);
                resolveBetBaseIndex();
                updateBetStepperUI({ syncSelection: false });
                updateBetLabel();
            });
        });
        if (window.IqwinTerminalInfoPages) {
            infoPagesController = window.IqwinTerminalInfoPages.init({
                onOpenChange(open) {
                    if (!open) return;
                    renderInfoPages();
                    infoPagesController?.refresh();
                }
            });
        }

        initSettingsMenu();
        if (window.IqwinTerminalFooter) {
            window.IqwinTerminalFooter.bind();
        }

    }

    function initReelsLedFrame() {
        const track = $('.verga-reels-led-track');
        if (!track) {
            return;
        }

        const ledPoints = [
            [4, 0], [8, 0], [12, 0], [16, 0], [20, 0], [24, 0], [28, 0], [32, 0], [36, 0], [40, 0], [44, 0], [48, 0], [52, 0], [56, 0], [60, 0], [64, 0], [68, 0], [72, 0], [76, 0], [80, 0], [84, 0], [88, 0], [92, 0], [96, 0],
            [100, 10], [100, 20], [100, 30], [100, 40], [100, 50], [100, 60], [100, 70], [100, 80], [100, 90],
            [96, 100], [92, 100], [88, 100], [84, 100], [80, 100], [76, 100], [72, 100], [68, 100], [64, 100], [60, 100], [56, 100], [52, 100], [48, 100], [44, 100], [40, 100], [36, 100], [32, 100], [28, 100], [24, 100], [20, 100], [16, 100], [12, 100], [8, 100], [4, 100],
            [0, 90], [0, 80], [0, 70], [0, 60], [0, 50], [0, 40], [0, 30], [0, 20], [0, 10]
        ];

        track.replaceChildren();

        ledPoints.forEach((point, index) => {
            const led = document.createElement('i');
            led.style.setProperty('--x', `${point[0]}%`);
            led.style.setProperty('--y', `${point[1]}%`);
            led.style.setProperty('--d', String(index));
            track.appendChild(led);
        });
    }

    symbolKeys.forEach((key) => {
        const img = new Image();
        img.src = symbolSrc(key);
    });

    applyUniformStyles();

    void (async () => {
        const loaded = await loadMechanicalReelStripsManifest();
        state.stripsReady = loaded || validateLoadedReelStrips(MECHANICAL_REEL_STRIPS);
        if (!loaded) {
            MECHANICAL_REEL_STRIPS = cloneReelStrips(DEFAULT_MECHANICAL_REEL_STRIPS);
        }
        if (window.IqwinSkillSpin) {
            window.IqwinSkillSpin.restoreIdleStops(state);
        }
        randomizeVisibleBoard();
        loadPreferences();
        renderInfoPages();
        bindEvents();
        if (window.MillionaireQuiz) {
            MillionaireQuiz.init({
                isBlocked: () => state.spinning,
                isSoundEnabled: () => state.soundEnabled,
                getOffer: () => state.halfBetOffer,
                formatCredits: (value) => formatBetNumber(toDisplayCredits(value)),
                onRefundApplied: (refundAmount, newBalance) => {
                    if (newBalance !== undefined && newBalance !== null) {
                        state.credits = Number(newBalance);
                    } else {
                        state.credits += refundAmount;
                    }
                    if (refundAmount > 0) {
                        const lastWin = $('#lastWinValue');
                        if (lastWin) {
                            lastWin.textContent = formatBalanceNumber(toDisplayCredits(refundAmount));
                        }
                    }
                    updateBalance();
                    notifyParentCredits();
                },
                onOfferConsumed: () => {
                    consumeHalfBetOffer();
                },
            });
        }
        updateHalfButton();
        bindKioskGuards();
        initReelsLedFrame();
        resolveBetBaseIndex();
        updateBetStepperUI();
        updateBetLabel();
        updatePreferenceControls();
        updateBalance();
        loadCredits().then(() => {
            updateBalance();
            notifyParentCredits();
            if (window.IqwinSkillSpin) {
                void window.IqwinSkillSpin.fetchIdleStops(state).then((stops) => {
                    if (!stops || state.spinning) {
                        return;
                    }
                    randomizeVisibleBoard();
                });
            }
            void flushPendingRoundSync().then((prepared) => {
                if (prepared && !prepared.ready && window.IqwinTerminalRoundSync) {
                    IqwinTerminalRoundSync.scheduleBackgroundRetry(terminalRoundSyncOptions());
                }
            });
        });
    })();
})();
