(function (global) {
    var DEFAULT_PORT = 17891;
    var ready = false;
    var base = 'http://127.0.0.1:' + DEFAULT_PORT + '/assets';

    function localPort() {
        try {
            var raw = localStorage.getItem('skill_terminal_credentials');
            if (!raw) {
                return DEFAULT_PORT;
            }
            var parsed = JSON.parse(raw);
            var port = Number(parsed && parsed.local_port);
            return port >= 1024 ? port : DEFAULT_PORT;
        } catch (error) {
            return DEFAULT_PORT;
        }
    }

    function probe() {
        base = 'http://127.0.0.1:' + localPort() + '/assets';
        try {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', base + '/manifest.json', false);
            xhr.send(null);
            if (xhr.status === 200) {
                var manifest = JSON.parse(xhr.responseText);
                if (manifest && manifest.ok) {
                    ready = true;
                    return;
                }
            }
        } catch (error) {}
        ready = false;
    }

    function toLocal(href) {
        if (!ready || !href) {
            return href;
        }
        try {
            var url = new URL(href, global.location.href);
            if (url.hostname === '127.0.0.1' || url.hostname === 'localhost') {
                return href;
            }
            var path = url.pathname || '';
            if (
                path.indexOf('/games/') === 0
                || path.indexOf('/images/') === 0
                || path.indexOf('/app/') === 0
            ) {
                return base + path;
            }
        } catch (error) {}
        return href;
    }

    function rewriteNode(node) {
        if (!node || node.nodeType !== 1) {
            return;
        }
        if (node.tagName === 'LINK' && String(node.rel || '').toLowerCase() === 'stylesheet' && node.href) {
            var mapped = toLocal(node.href);
            if (mapped !== node.href) {
                node.href = mapped;
            }
        }
        if ((node.tagName === 'IMG' || node.tagName === 'SOURCE' || node.tagName === 'VIDEO' || node.tagName === 'AUDIO') && node.getAttribute('src')) {
            var mappedSrc = toLocal(node.src);
            if (mappedSrc !== node.src) {
                node.src = mappedSrc;
            }
        }
    }

    function rewriteTree(root) {
        if (!root) {
            return;
        }
        rewriteNode(root);
        if (root.querySelectorAll) {
            root.querySelectorAll('link[rel="stylesheet"],img[src],source[src],video[src],audio[src]').forEach(rewriteNode);
        }
    }

    probe();
    global.IqwinLocalAssets = {
        ready: ready,
        base: base,
        resolve: toLocal
    };

    if (ready && typeof global.fetch === 'function') {
        var origFetch = global.fetch;
        global.fetch = function (input, init) {
            try {
                var href = typeof input === 'string' ? input : (input && input.url);
                var mapped = toLocal(href);
                if (mapped && mapped !== href) {
                    if (typeof input === 'string') {
                        input = mapped;
                    } else if (typeof Request !== 'undefined' && input instanceof Request) {
                        input = new Request(mapped, input);
                    }
                }
            } catch (error) {}
            return origFetch.call(global, input, init);
        };
    }

    if (ready && global.document && global.document.documentElement) {
        var observer = new MutationObserver(function (records) {
            records.forEach(function (record) {
                if (record.type === 'attributes') {
                    rewriteNode(record.target);
                    return;
                }
                record.addedNodes.forEach(function (node) {
                    rewriteTree(node);
                });
            });
        });
        observer.observe(global.document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['href', 'src'] });
        if (global.document.readyState === 'loading') {
            global.document.addEventListener('DOMContentLoaded', function () {
                rewriteTree(global.document);
            });
        } else {
            rewriteTree(global.document);
        }
    }
})(window);
