(function (global) {
    'use strict';

    function getCredentials() {
        const storage = localStorage.getItem('skill_terminal_credentials');
        const server = localStorage.getItem('skill_terminal_server');
        if (!storage || !server) {
            return null;
        }
        try {
            return {
                credentials: JSON.parse(storage),
                base: server.replace(/\/$/, '') + '/api/terminal'
            };
        } catch (error) {
            return null;
        }
    }

    function lastStopsStorageKey(gameId) {
        let code = 't';
        try {
            const parsed = JSON.parse(localStorage.getItem('skill_terminal_credentials') || '{}');
            if (parsed && parsed.terminal_code) {
                code = String(parsed.terminal_code);
            }
        } catch (error) {
        }
        return 'iqwin_last_reel_stops:' + code + ':' + String(gameId || 0);
    }

    function normalizeStops(raw) {
        if (!Array.isArray(raw) || raw.length < 5) {
            return null;
        }
        const stops = [];
        for (let i = 0; i < 5; i += 1) {
            const value = Number(raw[i]);
            if (!Number.isFinite(value)) {
                return null;
            }
            stops.push(Math.max(0, Math.round(value)));
        }
        return stops;
    }

    function readLastStops(gameId) {
        try {
            return normalizeStops(JSON.parse(localStorage.getItem(lastStopsStorageKey(gameId)) || 'null'));
        } catch (error) {
            return null;
        }
    }

    function writeLastStops(gameId, stops) {
        const normalized = normalizeStops(stops);
        if (!normalized) {
            return null;
        }
        try {
            localStorage.setItem(lastStopsStorageKey(gameId), JSON.stringify(normalized));
        } catch (error) {
        }
        return normalized;
    }

    function applyIdleStops(state, stops) {
        const normalized = normalizeStops(stops);
        if (!state || !normalized) {
            return null;
        }
        state.lastSettledStops = normalized.slice();
        state.roundStartStops = normalized.slice();
        writeLastStops(state.gameId, normalized);
        return normalized;
    }

    function restoreIdleStops(state) {
        if (!state) {
            return null;
        }
        const local = readLastStops(state.gameId);
        if (!local) {
            return null;
        }
        state.lastSettledStops = local.slice();
        state.roundStartStops = local.slice();
        return local;
    }

    function rememberSettledStops(state, stops) {
        return applyIdleStops(state, stops);
    }

    async function fetchIdleStops(state) {
        if (!state) {
            return null;
        }
        const auth = getCredentials();
        if (!auth) {
            return restoreIdleStops(state);
        }
        try {
            const response = await fetch(`${auth.base}/session.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Terminal-Code': auth.credentials.terminal_code,
                    'X-Terminal-Secret': auth.credentials.api_secret
                },
                body: JSON.stringify({
                    action: 'last_stops',
                    game_id: state.gameId
                })
            });
            const data = await response.json();
            const fromServer = data?.ok ? normalizeStops(data.last_stops) : null;
            if (fromServer) {
                return applyIdleStops(state, fromServer);
            }
        } catch (error) {
        }
        return restoreIdleStops(state);
    }

    function applyStart(state, data) {
        if (!state || !data) {
            return;
        }
        const startStops = Array.isArray(data.start_stops) ? data.start_stops.slice(0, 5) : [0, 0, 0, 0, 0];
        while (startStops.length < 5) {
            startStops.push(0);
        }
        const keepVisualClock = Number.isFinite(Number(state.spinLocalT0)) && state.spinning;
        if (!keepVisualClock || !Array.isArray(state.roundStartStops) || state.roundStartStops.length < 5) {
            state.roundStartStops = startStops.map((value) => Math.max(0, Number(value) || 0));
        }
        state.reelScrollMult = Number(data.reel_scroll_mult || 1) || 1;
        state.autoStopMs = Number(data.auto_stop_ms || 5000) || 5000;
        const speedApi = global.IqwinTerminalReelSpeed;
        const fromServer = Number(data.min_player_stop_ms);
        const fallbackStop = speedApi && typeof speedApi.minPlayerStopMs === 'function'
            ? speedApi.minPlayerStopMs(state.reelScrollMult)
            : 1000;
        state.minPlayerStopMs = Number.isFinite(fromServer) && fromServer > 0
            ? Math.max(1000, Math.round(fromServer))
            : Math.max(1000, fallbackStop);
        state.spinT0Ms = Number(data.spin_t0_ms || 0) || 0;
        if (!keepVisualClock) {
            state.spinLocalT0 = performance.now();
        }
        if (!state.reelClickElapsed || typeof state.reelClickElapsed !== 'object') {
            state.reelClickElapsed = {};
        }
        state.serverStops = Array.isArray(data.stops) ? data.stops.slice() : [null, null, null, null, null];
        if (Array.isArray(data.speeds) && data.speeds.length) {
            state.serverSpeeds = data.speeds.map((value) => Number(value) || 0);
        }
    }

    function minPlayerStopMs(state) {
        const stored = Number(state?.minPlayerStopMs);
        if (Number.isFinite(stored) && stored > 0) {
            return Math.max(1000, Math.round(stored));
        }
        const speedApi = global.IqwinTerminalReelSpeed;
        const mult = Number(state?.reelScrollMult || 1) || 1;
        const fallback = speedApi && typeof speedApi.minPlayerStopMs === 'function'
            ? speedApi.minPlayerStopMs(mult)
            : 1000;
        return Math.max(1000, fallback);
    }

    function remainingArmMs(state) {
        return Math.max(0, minPlayerStopMs(state) - captureElapsed(state, 'player'));
    }

    function isPlayerStopArmed(state) {
        return remainingArmMs(state) <= 0;
    }

    function clampPlayerElapsed(state, elapsedMs) {
        return Math.max(minPlayerStopMs(state), Math.max(0, Math.round(Number(elapsedMs) || 0)));
    }

    function captureElapsed(state, source) {
        if (!state) {
            return 0;
        }
        if (source === 'auto') {
            return Math.max(0, Math.round(Number(state.autoStopMs || 5000)));
        }
        return Math.max(0, Math.round(performance.now() - Number(state.spinLocalT0 || performance.now())));
    }

    function rememberClickElapsed(state, reels, elapsedMs) {
        if (!state) {
            return;
        }
        if (!state.reelClickElapsed || typeof state.reelClickElapsed !== 'object') {
            state.reelClickElapsed = {};
        }
        const elapsed = Math.max(0, Math.round(Number(elapsedMs) || 0));
        (reels || []).forEach((reelIndex) => {
            const index = Number(reelIndex);
            if (!Number.isFinite(index)) {
                return;
            }
            state.reelClickElapsed[index] = elapsed;
        });
    }

    function localStopIndex(state, reelIndex, source, stripLength, elapsedOverride) {
        const speedApi = global.IqwinTerminalReelSpeed;
        const start = Number(state.roundStartStops?.[reelIndex] || 0);
        const elapsed = Number.isFinite(Number(elapsedOverride))
            ? Math.max(0, Number(elapsedOverride))
            : (source === 'auto'
                ? Number(state.autoStopMs || 5000)
                : Math.max(0, performance.now() - Number(state.spinLocalT0 || performance.now())));
        const playerElapsed = source === 'auto' ? elapsed : clampPlayerElapsed(state, elapsed);
        const speed = state.serverSpeeds?.[reelIndex]
            || (speedApi ? speedApi.getReelSpinScrollSpeed(reelIndex, state.reelScrollMult || 1) : 1.5);
        return speedApi
            ? speedApi.resolveStopIndex(start, playerElapsed, speed, stripLength)
            : start;
    }

    function reelSpeedFor(state, reelIndex) {
        const speedApi = global.IqwinTerminalReelSpeed;
        return state.serverSpeeds?.[reelIndex]
            || (speedApi ? speedApi.getReelSpinScrollSpeed(reelIndex, state.reelScrollMult || 1) : 1.5);
    }

    function elapsedMatchingStop(state, reelIndex, visualStop, stripLength, clockElapsed, source) {
        if (source === 'auto') {
            return Math.max(0, Math.round(Number(state.autoStopMs || 5000)));
        }
        const length = Math.max(1, Number(stripLength) || 1);
        const start = Number(state.roundStartStops?.[reelIndex] || 0);
        const speed = Number(reelSpeedFor(state, reelIndex)) || 0;
        const locked = ((Number(visualStop) % length) + length) % length;
        const delta = ((locked - start) % length + length) % length;
        const clock = Math.max(0, Number(clockElapsed) || 0);
        if (!(speed > 0)) {
            return Math.round(clock);
        }
        const estimated = (clock / 1000) * speed;
        let loops = Math.round((estimated - delta) / length);
        if (loops < 0) {
            loops = 0;
        }
        const traveled = loops * length + delta;
        return Math.max(0, Math.round((traveled / speed) * 1000));
    }

    async function takeStops(state, reelIndexes, source, stripLengthFor) {
        const reels = (reelIndexes || []).map((value) => Number(value)).filter((value) => value >= 0 && value <= 4);
        const resolved = {};
        const auth = getCredentials();
        const elapsedByReel = {};
        reels.forEach((reelIndex) => {
            let value = Number(state.reelClickElapsed?.[reelIndex]);
            if (!Number.isFinite(value)) {
                value = captureElapsed(state, source || 'player');
            }
            if ((source || 'player') !== 'auto') {
                value = clampPlayerElapsed(state, value);
            }
            elapsedByReel[reelIndex] = value;
            rememberClickElapsed(state, [reelIndex], value);
        });
        const elapsedValues = Object.keys(elapsedByReel).map((key) => elapsedByReel[key]);
        const elapsedMs = elapsedValues.length ? Math.min.apply(null, elapsedValues) : captureElapsed(state, source || 'player');

        const claimedStops = {};
        reels.forEach((reelIndex) => {
            const stop = Number(state.roundStopIndexes?.[reelIndex]);
            if (Number.isFinite(stop)) {
                claimedStops[reelIndex] = Math.max(0, Math.round(stop));
            }
        });

        async function requestStops() {
            const response = await fetch(`${auth.base}/session.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Terminal-Code': auth.credentials.terminal_code,
                    'X-Terminal-Secret': auth.credentials.api_secret
                },
                body: JSON.stringify({
                    action: 'reel_stop',
                    game_id: state.gameId,
                    session_id: state.sessionId,
                    reels,
                    source: source || 'player',
                    elapsed_ms: elapsedMs,
                    elapsed_by_reel: elapsedByReel,
                    stops: claimedStops
                })
            });
            const data = await response.json();
            if (!data?.ok || !Array.isArray(data.stops)) {
                return false;
            }
            state.serverStops = data.stops.slice();
            reels.forEach((reelIndex) => {
                if (data.stops[reelIndex] !== null && data.stops[reelIndex] !== undefined) {
                    resolved[reelIndex] = Number(data.stops[reelIndex]);
                }
            });
            if (typeof data.skill_stop_used === 'boolean') {
                state.serverSkillStopUsed = data.skill_stop_used;
            }
            return reels.every((reelIndex) => resolved[reelIndex] !== undefined);
        }

        if (auth && state.sessionId) {
            for (let attempt = 0; attempt < 2; attempt += 1) {
                try {
                    if (await requestStops()) {
                        break;
                    }
                } catch (error) {
                }
                if (attempt < 1) {
                    await new Promise((resolve) => setTimeout(resolve, 80));
                }
            }
        }
        reels.forEach((reelIndex) => {
            if (resolved[reelIndex] === undefined) {
                const length = typeof stripLengthFor === 'function' ? stripLengthFor(reelIndex) : 1;
                resolved[reelIndex] = localStopIndex(state, reelIndex, source, length, elapsedByReel[reelIndex]);
            }
        });
        return resolved;
    }

    global.IqwinSkillSpin = {
        applyStart,
        takeStops,
        localStopIndex,
        captureElapsed,
        rememberClickElapsed,
        restoreIdleStops,
        rememberSettledStops,
        fetchIdleStops,
        elapsedMatchingStop,
        minPlayerStopMs,
        remainingArmMs,
        isPlayerStopArmed,
        clampPlayerElapsed
    };
})(window);
