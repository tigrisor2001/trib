(function (global) {
    'use strict';

    const live = new Set();
    let frame = 0;
    let lastTime = 0;
    let loopsRef = null;

    function rowCount(reel) {
        if (!reel || !reel.children) return 3;
        let count = 0;
        for (let i = 0; i < reel.children.length; i += 1) {
            const child = reel.children[i];
            if (child.classList && child.classList.contains('boss-crown-cell')) count += 1;
        }
        return count > 0 ? count : 3;
    }

    function rowHeight(reel) {
        const node = reel || document.querySelector('.boss-crown-reel');
        const height = node && node.getBoundingClientRect ? node.getBoundingClientRect().height : 0;
        if (!(height > 0)) return 0;
        return height / rowCount(node);
    }

    function lockStrip(strip, height) {
        const count = strip.children.length;
        if (!(height > 0) || count === 0) return;
        strip.style.height = (height * count) + 'px';
        strip.style.gridTemplateRows = 'repeat(' + count + ', ' + height + 'px)';
        Array.prototype.forEach.call(strip.children, function (item) {
            item.style.setProperty('height', height + 'px', 'important');
            item.style.setProperty('min-height', height + 'px', 'important');
            item.style.setProperty('max-height', height + 'px', 'important');
            item.style.setProperty('aspect-ratio', 'auto', 'important');
        });
    }

    function place(loop, strip) {
        const height = loop.rowHeight;
        const spinLength = loop.spinLength;
        if (!(height > 0) || !(spinLength > 0)) return;
        const loopHeight = height * spinLength;
        let translate = loop.origin + loop.travel;
        while (translate > -loopHeight) translate -= loopHeight;
        while (translate <= -2 * loopHeight) translate += loopHeight;
        loop.offset = ((-translate) % loopHeight + loopHeight) % loopHeight;
        strip.style.transform = 'translate3d(0, ' + translate + 'px, 0)';
    }

    function tick(now) {
        const dt = lastTime ? Math.min(0.05, (now - lastTime) / 1000) : 0;
        lastTime = now;
        live.forEach(function (reel) {
            const loop = loopsRef && loopsRef.get(reel);
            const strip = reel.querySelector('.boss-crown-spin-strip');
            if (!loop || loop.cancelled || !strip || !reel.classList.contains('is-spinning')) {
                stop(reel, loopsRef);
                return;
            }
            if (!(loop.rowHeight > 0)) {
                const height = rowHeight(reel);
                if (!(height > 0)) return;
                lockStrip(strip, height);
                loop.rowHeight = height;
                loop.origin = -(loop.spinLength + loop.startStop) * height;
                loop.offset = loop.startStop * height;
            }
            loop.travel += loop.rowHeight * loop.speed * dt;
            place(loop, strip);
        });
        if (live.size) {
            frame = global.requestAnimationFrame(tick);
        } else {
            frame = 0;
            lastTime = 0;
        }
    }

    function stop(reel, loops) {
        if (!reel || !loops) return;
        const loop = loops.get(reel);
        if (!loop) return;
        loop.cancelled = true;
        live.delete(reel);
        const strip = reel.querySelector('.boss-crown-spin-strip');
        if (strip) {
            strip.style.transform = 'translate3d(0, ' + (-loop.offset) + 'px, 0)';
        }
        loops.delete(reel);
        if (!live.size && frame) {
            global.cancelAnimationFrame(frame);
            frame = 0;
            lastTime = 0;
        }
    }

    function start(reel, reelIndex, loops, stripLength, startStop) {
        if (!reel || !loops) return;
        loopsRef = loops;
        stop(reel, loops);
        const strip = reel.querySelector('.boss-crown-spin-strip');
        if (!strip) return;
        const length = Math.max(1, Number(strip.dataset.spinLength) || Number(stripLength) || 1);
        const height = rowHeight(reel);
        const originStop = ((Number(startStop) % length) + length) % length;
        if (height > 0) lockStrip(strip, height);
        const speedApi = global.IqwinTerminalReelSpeed;
        const speed = speedApi && typeof speedApi.getReelSpinScrollSpeed === 'function'
            ? speedApi.getReelSpinScrollSpeed(0, 1.5)
            : 2.26;
        const loop = {
            cancelled: false,
            offset: originStop * height,
            travel: 0,
            origin: height > 0 ? -(length + originStop) * height : 0,
            rowHeight: height,
            spinLength: length,
            startStop: originStop,
            speed: speed
        };
        loops.set(reel, loop);
        if (height > 0) place(loop, strip);
        live.add(reel);
        if (!frame) {
            lastTime = 0;
            frame = global.requestAnimationFrame(tick);
        }
    }

    global.IqwinBrainReels = { start: start, stop: stop };
})(window);
