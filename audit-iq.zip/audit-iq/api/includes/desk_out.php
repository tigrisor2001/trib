<?php

function deskOutEnsureTable(): void
{
    static $ready = false;
    if ($ready) {
        return;
    }
    try {
    getDB()->query(
        'CREATE TABLE IF NOT EXISTS desk_out_requests (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            station_id int(10) UNSIGNED NOT NULL,
            terminal_id int(10) UNSIGNED NOT NULL,
            amount decimal(12,2) NOT NULL,
            credits int(11) NOT NULL DEFAULT 0,
            status enum(\'pending\',\'approved\',\'rejected\') NOT NULL DEFAULT \'pending\',
            approved_by int(10) UNSIGNED DEFAULT NULL,
            approved_at datetime DEFAULT NULL,
            created_at datetime NOT NULL DEFAULT current_timestamp(),
            PRIMARY KEY (id),
            KEY idx_desk_out_pending (station_id, status),
            KEY idx_desk_out_term (terminal_id, status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
    } catch (Throwable $e) {
    }
    $ready = true;
}

function deskOutPendingForTerminal(int $terminalId): ?array
{
    deskOutEnsureTable();
    $row = getDB()->fetchOne(
        'SELECT * FROM desk_out_requests WHERE terminal_id = ? AND status = ? ORDER BY id DESC LIMIT 1',
        [$terminalId, 'pending']
    );
    return $row ?: null;
}

function deskOutCreateRequest(array $terminal): array
{
    deskOutEnsureTable();
    $terminalId = (int) ($terminal['id'] ?? 0);
    $stationId = (int) ($terminal['station_id'] ?? 0);
    if ($terminalId < 1 || $stationId < 1) {
        return ['ok' => false, 'message' => 'Terminal invalid.'];
    }
    if (function_exists('termApiTerminalHasOpenGame') && termApiTerminalHasOpenGame($terminalId)) {
        return ['ok' => false, 'message' => 'Inchide jocul pentru a retrage.'];
    }
    $existing = deskOutPendingForTerminal($terminalId);
    if ($existing) {
        return [
            'ok' => true,
            'pending' => true,
            'request_id' => (int) $existing['id'],
            'amount' => round((float) $existing['amount'], 2),
        ];
    }
    $rate = termTerminalCreditRate($terminal);
    $credits = (int) floor(termApiCreditsBalance($terminal));
    $amount = round($credits * $rate, 2);
    if ($amount < 0.01) {
        return ['ok' => false, 'message' => 'Nu exista sold de retras.'];
    }
    $id = (int) getDB()->insert('desk_out_requests', [
        'station_id' => $stationId,
        'terminal_id' => $terminalId,
        'amount' => $amount,
        'credits' => $credits,
        'status' => 'pending',
    ]);
    return [
        'ok' => true,
        'pending' => true,
        'request_id' => $id,
        'amount' => $amount,
    ];
}

function deskOutPayload(?array $row): ?array
{
    if (!$row) {
        return null;
    }
    return [
        'id' => (int) $row['id'],
        'amount' => round((float) $row['amount'], 2),
        'status' => (string) $row['status'],
    ];
}

function deskOutListPending(int $stationId): array
{
    deskOutEnsureTable();
    $rows = getDB()->fetchAll(
        'SELECT r.*, t.name AS terminal_name, t.terminal_code
         FROM desk_out_requests r
         LEFT JOIN terminals t ON t.id = r.terminal_id
         WHERE r.station_id = ? AND r.status = ?
         ORDER BY r.id ASC',
        [$stationId, 'pending']
    ) ?: [];
    $terms = getDB()->fetchAll(
        'SELECT id FROM terminals WHERE station_id = ? AND is_active = 1 ORDER BY id ASC',
        [$stationId]
    ) ?: [];
    $index = [];
    foreach ($terms as $i => $term) {
        $index[(int) $term['id']] = $i + 1;
    }
    $out = [];
    foreach ($rows as $row) {
        $tid = (int) $row['terminal_id'];
        $label = function_exists('deskShortCode')
            ? deskShortCode([
                'terminal_code' => (string) ($row['terminal_code'] ?? ''),
                'name' => (string) ($row['terminal_name'] ?? ''),
            ], (int) ($index[$tid] ?? 1))
            : ('T' . str_pad((string) ($index[$tid] ?? 1), 2, '0', STR_PAD_LEFT));
        $nr = preg_replace('/^T/i', '', $label);
        $amount = round((float) $row['amount'], 2);
        $out[] = [
            'id' => (int) $row['id'],
            'terminal_id' => $tid,
            'label' => 'Terminal ' . str_pad((string) $nr, 2, '0', STR_PAD_LEFT),
            'amount' => $amount,
            'amount_text' => number_format($amount, 2, ',', '.') . ' LEI',
        ];
    }
    return $out;
}

function deskOutMarkDone(int $requestId, int $userId, string $status = 'approved'): void
{
    deskOutEnsureTable();
    getDB()->update('desk_out_requests', [
        'status' => $status,
        'approved_by' => $userId,
        'approved_at' => date('Y-m-d H:i:s'),
    ], 'id = :id', ['id' => $requestId]);
}

function deskOutMarkTerminalDone(int $terminalId, int $userId, string $status = 'approved'): void
{
    $row = deskOutPendingForTerminal($terminalId);
    if ($row) {
        deskOutMarkDone((int) $row['id'], $userId, $status);
    }
}
