<?php

declare(strict_types=1);

final class SkillSpinPhysics
{
    public const REEL_COUNT = 5;
    public const REEL_SCROLL_SPEED = 0.13125;
    public const REEL_SPEED_BASE = 11.5;
    public const REEL_SPEED_STEP = 3.5;
    public const REEL_SPEED_STEP_TAIL = 1.55;
    public const STOP_TIMEOUT_MS = 5000;

    public const SPEED_PROFILES = [
        'normal' => ['reel_scroll_mult' => 1.0, 'play_stop_delay_ms' => 480],
        'rapid' => ['reel_scroll_mult' => 1.5, 'play_stop_delay_ms' => 300],
        'turbo' => ['reel_scroll_mult' => 2.15, 'play_stop_delay_ms' => 180],
    ];

    public static function nowMs(): int
    {
        return (int) round(microtime(true) * 1000);
    }

    public static function normalizeSpeedProfile(string $profile): string
    {
        $key = strtolower(trim($profile));
        return array_key_exists($key, self::SPEED_PROFILES) ? $key : 'normal';
    }

    public static function reelSpeedFactor(int $reelIndex): float
    {
        $index = max(0, $reelIndex);
        if ($index <= 2) {
            return self::REEL_SPEED_BASE + $index * self::REEL_SPEED_STEP;
        }

        return self::REEL_SPEED_BASE + 2 * self::REEL_SPEED_STEP + ($index - 2) * self::REEL_SPEED_STEP_TAIL;
    }

    public static function reelSpeed(int $reelIndex, float $reelScrollMult): float
    {
        $mult = $reelScrollMult > 0 ? $reelScrollMult : 1.0;

        return self::reelSpeedFactor($reelIndex) * $mult * self::REEL_SCROLL_SPEED;
    }

    public static function minPlayerStopMs(float $reelScrollMult): int
    {
        return 1000;
    }

    public static function resolveStopIndex(int $startStop, int $elapsedMs, float $speed, int $stripLength): int
    {
        if ($stripLength <= 0) {
            return 0;
        }
        $elapsedMs = max(0, $elapsedMs);
        $traveled = ($elapsedMs / 1000.0) * $speed;
        $raw = $startStop + (int) round($traveled);
        $mod = $raw % $stripLength;
        if ($mod < 0) {
            $mod += $stripLength;
        }

        return $mod;
    }

    public static function stopDistance(int $left, int $right, int $length): int
    {
        if ($length <= 0) {
            return 0;
        }
        $delta = abs($left - $right) % $length;
        return (int) min($delta, $length - $delta);
    }

    public static function alignClaimedStop(int $physicsStop, int $claimedStop, int $length): int
    {
        if ($length <= 0) {
            return $physicsStop;
        }
        return (($claimedStop % $length) + $length) % $length;
    }

    public static function alignStopsToVisible(array $physicsStops, array $claimedStops, string $engineClass): array
    {
        $aligned = [];
        for ($i = 0; $i < self::REEL_COUNT; $i += 1) {
            $length = (int) $engineClass::stripLength($i);
            $physics = (int) ($physicsStops[$i] ?? 0);
            $hasClaim = array_key_exists($i, $claimedStops) || array_key_exists((string) $i, $claimedStops);
            if (!$hasClaim) {
                $aligned[$i] = $physics;
                continue;
            }
            $claimed = (int) ($claimedStops[$i] ?? $claimedStops[(string) $i]);
            $aligned[$i] = self::alignClaimedStop($physics, $claimed, $length);
        }

        return $aligned;
    }

    public static function ensureSchema(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;
        $db = getDB();
        try {
            $db->query('ALTER TABLE game_sessions ADD COLUMN spin_physics MEDIUMTEXT NULL');
        } catch (Throwable $e) {
        }
        try {
            $db->query('ALTER TABLE terminal_transactions ADD COLUMN idempotency_key varchar(80) NULL');
        } catch (Throwable $e) {
        }
        try {
            $db->query(
                'ALTER TABLE terminal_transactions
                 ADD UNIQUE KEY uq_terminal_tx_idempotency (terminal_id, type, idempotency_key)'
            );
        } catch (Throwable $e) {
        }
    }

    public static function decode(?string $raw): ?array
    {
        if ($raw === null || $raw === '') {
            return null;
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : null;
    }

    public static function encode(array $physics): string
    {
        return json_encode($physics, JSON_UNESCAPED_UNICODE);
    }

    public static function loadLastStartStops(int $terminalId, int $gameId, string $engineClass): array
    {
        $stops = array_fill(0, self::REEL_COUNT, 0);
        try {
            $row = getDB()->fetchOne(
                'SELECT spin_physics FROM game_sessions
                 WHERE terminal_id = ? AND game_id = ? AND ended_at IS NOT NULL AND spin_physics IS NOT NULL
                 ORDER BY id DESC LIMIT 1',
                [$terminalId, $gameId]
            );
            $prev = self::decode($row['spin_physics'] ?? null);
            if (is_array($prev['stops'] ?? null)) {
                for ($i = 0; $i < self::REEL_COUNT; $i += 1) {
                    $length = (int) $engineClass::stripLength($i);
                    $stops[$i] = ((int) ($prev['stops'][$i] ?? 0) % max(1, $length) + $length) % max(1, $length);
                }
            }
        } catch (Throwable $e) {
        }

        return $stops;
    }

    public static function createForStart(array $body, int $terminalId, int $gameId, string $engineClass): array
    {
        $profile = 'rapid';
        $playStop = filter_var($body['play_stop_mode'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $conf = self::SPEED_PROFILES[$profile];
        $mult = (float) $conf['reel_scroll_mult'];
        $minPlayerStopMs = self::minPlayerStopMs($mult);
        $autoStopMs = $playStop
            ? max(1000, (int) $conf['play_stop_delay_ms'])
            : self::STOP_TIMEOUT_MS;
        $startStops = self::loadLastStartStops($terminalId, $gameId, $engineClass);
        $speeds = [];
        $lengths = [];
        $flatSpeed = self::reelSpeed(0, $mult);
        for ($i = 0; $i < self::REEL_COUNT; $i += 1) {
            $speeds[$i] = $flatSpeed;
            $lengths[$i] = (int) $engineClass::stripLength($i);
        }

        return [
            't0_ms' => self::nowMs(),
            'speed_profile' => $profile,
            'reel_scroll_mult' => $mult,
            'play_stop_mode' => $playStop,
            'auto_stop_ms' => $autoStopMs,
            'min_player_stop_ms' => $minPlayerStopMs,
            'start_stops' => $startStops,
            'speeds' => $speeds,
            'strip_lengths' => $lengths,
            'stops' => array_fill(0, self::REEL_COUNT, null),
            'events' => [],
        ];
    }

    public static function payload(array $physics): array
    {
        return [
            'spin_t0_ms' => (int) ($physics['t0_ms'] ?? 0),
            'start_stops' => array_values($physics['start_stops'] ?? array_fill(0, self::REEL_COUNT, 0)),
            'reel_scroll_mult' => (float) ($physics['reel_scroll_mult'] ?? 1),
            'speed_profile' => (string) ($physics['speed_profile'] ?? 'normal'),
            'play_stop_mode' => !empty($physics['play_stop_mode']),
            'auto_stop_ms' => (int) ($physics['auto_stop_ms'] ?? self::STOP_TIMEOUT_MS),
            'min_player_stop_ms' => (int) ($physics['min_player_stop_ms'] ?? self::minPlayerStopMs((float) ($physics['reel_scroll_mult'] ?? 1))),
            'speeds' => array_values($physics['speeds'] ?? []),
            'stops' => array_values($physics['stops'] ?? array_fill(0, self::REEL_COUNT, null)),
        ];
    }

    public static function save(int $sessionId, array $physics): void
    {
        getDB()->update('game_sessions', [
            'spin_physics' => self::encode($physics),
        ], 'id = :id', ['id' => $sessionId]);
    }

    public static function attachToNewSession(int $sessionId, int $terminalId, int $gameId, string $engineClass, array $body): array
    {
        self::ensureSchema();
        $physics = self::createForStart($body, $terminalId, $gameId, $engineClass);
        self::save($sessionId, $physics);

        return $physics;
    }

    public static function applyStops(array $physics, array $reelIndexes, string $source, string $engineClass, ?int $clickElapsedMs = null, ?array $clickElapsedByReel = null, ?array $claimedStops = null): array
    {
        $now = self::nowMs();
        $t0 = (int) ($physics['t0_ms'] ?? $now);
        $autoStop = (int) ($physics['auto_stop_ms'] ?? self::STOP_TIMEOUT_MS);
        $keepPlayer = ($source === 'player' || $source === 'player_all');
        $serverElapsed = max(0, $now - $t0);
        $elapsed = $serverElapsed;
        if ($keepPlayer) {
            if ($clickElapsedMs !== null) {
                $claimed = max(0, $clickElapsedMs);
                if (abs($claimed - $serverElapsed) <= 3000) {
                    $elapsed = $claimed;
                }
            }
            if ($elapsed > $autoStop) {
                $elapsed = $autoStop;
            }
            $minPlayer = (int) ($physics['min_player_stop_ms'] ?? self::minPlayerStopMs((float) ($physics['reel_scroll_mult'] ?? 1)));
            if ($minPlayer > 0 && $elapsed < $minPlayer) {
                $elapsed = $minPlayer;
            }
        } else {
            $elapsed = $autoStop;
            $source = 'auto';
        }
        if ($source === 'player_all') {
            $source = 'player';
        }

        $stops = $physics['stops'] ?? array_fill(0, self::REEL_COUNT, null);
        $events = $physics['events'] ?? [];

        foreach ($reelIndexes as $reelIndex) {
            $reelIndex = (int) $reelIndex;
            if ($reelIndex < 0 || $reelIndex >= self::REEL_COUNT) {
                continue;
            }
            if ($stops[$reelIndex] !== null) {
                continue;
            }
            $elapsedReel = $elapsed;
            if ($keepPlayer && is_array($clickElapsedByReel) && array_key_exists($reelIndex, $clickElapsedByReel)) {
                $claimedReel = max(0, (int) $clickElapsedByReel[$reelIndex]);
                if (abs($claimedReel - $serverElapsed) <= 3000) {
                    $elapsedReel = $claimedReel;
                }
                if ($elapsedReel > $autoStop) {
                    $elapsedReel = $autoStop;
                }
                $minPlayer = (int) ($physics['min_player_stop_ms'] ?? self::minPlayerStopMs((float) ($physics['reel_scroll_mult'] ?? 1)));
                if ($minPlayer > 0 && $elapsedReel < $minPlayer) {
                    $elapsedReel = $minPlayer;
                }
            }
            $start = (int) ($physics['start_stops'][$reelIndex] ?? 0);
            $scrollMult = (float) ($physics['reel_scroll_mult'] ?? 1);
            $speed = (float) ($physics['speeds'][$reelIndex] ?? self::reelSpeed(0, $scrollMult));
            $length = (int) ($physics['strip_lengths'][$reelIndex] ?? $engineClass::stripLength($reelIndex));
            $stop = self::resolveStopIndex($start, $elapsedReel, $speed, $length);
            if (is_array($claimedStops) && (array_key_exists($reelIndex, $claimedStops) || array_key_exists((string) $reelIndex, $claimedStops))) {
                $claimed = (int) ($claimedStops[$reelIndex] ?? $claimedStops[(string) $reelIndex]);
                $stop = self::alignClaimedStop($stop, $claimed, $length);
            }
            $stops[$reelIndex] = $stop;
            $events[] = [
                'reel' => $reelIndex,
                'elapsed_ms' => $elapsedReel,
                'source' => $source,
                'stop' => $stop,
                'at_ms' => $now,
            ];
        }

        $physics['stops'] = $stops;
        $physics['events'] = $events;

        return $physics;
    }

    public static function finalizeAutoRemaining(array $physics, string $engineClass): array
    {
        $remaining = [];
        for ($i = 0; $i < self::REEL_COUNT; $i += 1) {
            if (($physics['stops'][$i] ?? null) === null) {
                $remaining[] = $i;
            }
        }
        if ($remaining === []) {
            return $physics;
        }

        return self::applyStops($physics, $remaining, 'auto', $engineClass);
    }

    public static function skillStopUsed(array $physics): bool
    {
        if (!empty($physics['play_stop_mode'])) {
            return true;
        }
        $player = [];
        foreach ($physics['events'] ?? [] as $event) {
            if (($event['source'] ?? '') === 'player') {
                $player[(int) ($event['reel'] ?? -1)] = true;
            }
        }

        return count($player) >= self::REEL_COUNT;
    }

    public static function resolvedStops(array $physics): ?array
    {
        $stops = [];
        for ($i = 0; $i < self::REEL_COUNT; $i += 1) {
            if (!isset($physics['stops'][$i]) || $physics['stops'][$i] === null) {
                return null;
            }
            $stops[$i] = (int) $physics['stops'][$i];
        }

        return $stops;
    }
}
