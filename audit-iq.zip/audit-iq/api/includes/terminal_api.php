<?php

require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/play_visits.php';

function termApiTerminalFromRequest(): ?array
{
    $json = termApiReadJsonBodyCached();
    $terminalCode = trim((string) termApiFirstNonEmpty([
        $_SERVER['HTTP_X_TERMINAL_CODE'] ?? null,
        $_POST['terminal_code'] ?? null,
        $json['terminal_code'] ?? null,
    ]));
    $apiSecret = trim((string) termApiFirstNonEmpty([
        $_SERVER['HTTP_X_TERMINAL_SECRET'] ?? null,
        $_POST['api_secret'] ?? null,
        $json['api_secret'] ?? null,
    ]));

    if ($terminalCode === '' || $apiSecret === '') {
        return null;
    }

    try {
        $terminal = getDB()->fetchOne(
            'SELECT * FROM terminals WHERE terminal_code = ? AND api_secret = ? AND is_active = 1 LIMIT 1',
            [$terminalCode, $apiSecret]
        );

        return $terminal ?: null;
    } catch (Exception $e) {
        return null;
    }
}

function termApiFirstNonEmpty(array $values): string
{
    foreach ($values as $value) {
        if ($value === null) {
            continue;
        }
        $text = trim((string) $value);
        if ($text !== '') {
            return $text;
        }
    }
    return '';
}

function termApiReadJsonBodyCached(): array
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $cached = termApiReadJsonBody();
    return $cached;
}

function termApiRequireTerminal(): array
{
    termApiEnsureStackerColumns();
    termEnsurePlayVisitsTable();
    $terminal = termApiTerminalFromRequest();
    if ($terminal === null) {
        termJson(['ok' => false, 'message' => 'Terminal neautorizat.'], 401);
    }

    if ($terminal['status'] === 'blocked') {
        termJson(['ok' => false, 'message' => 'Terminal blocat.'], 403);
    }

    return $terminal;
}

function termApiReadJsonBody(): array
{
    static $done = false;
    static $decoded = [];
    if ($done) {
        return $decoded;
    }
    $done = true;

    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        $decoded = [];
        return $decoded;
    }

    $parsed = json_decode($raw, true);
    $decoded = is_array($parsed) ? $parsed : [];
    return $decoded;
}

function termApiActiveGames(): array
{
    return getDB()->fetchAll(
        'SELECT id, slot_number, slug, title, subtitle, icon_key, status, is_visible, is_frozen, game_url, min_bet, max_bet, sort_order
         FROM games
         WHERE is_visible = 1
         ORDER BY sort_order ASC, slot_number ASC'
    );
}

function termApiUpdateHeartbeat(array $terminal): void
{
    getDB()->update('terminals', [
        'status' => $terminal['status'] === 'maintenance' ? 'maintenance' : 'online',
        'last_heartbeat_at' => date('Y-m-d H:i:s'),
        'last_ip' => $_SERVER['REMOTE_ADDR'] ?? null,
    ], 'id = :id', ['id' => (int) $terminal['id']]);
}

function termApiMarkOffline(int $minutes = 3): void
{
    if (function_exists('termMarkStaleTerminalsOffline')) {
        termMarkStaleTerminalsOffline($minutes);
        return;
    }

    $minutes = max(1, $minutes);
    try {
        getDB()->query(
            "UPDATE terminals
             SET status = 'offline'
             WHERE status = 'online'
               AND (last_heartbeat_at IS NULL OR last_heartbeat_at < DATE_SUB(NOW(), INTERVAL {$minutes} MINUTE))"
        );
    } catch (Throwable $e) {
        error_log('termApiMarkOffline: ' . $e->getMessage());
    }
}

function termApiCloseAllOpenGameSessions(int $terminalId): void
{
    try {
        getDB()->query(
            'UPDATE game_sessions SET ended_at = ? WHERE terminal_id = ? AND ended_at IS NULL',
            [date('Y-m-d H:i:s'), $terminalId]
        );
    } catch (Throwable $e) {
        error_log('termApiCloseAllOpenGameSessions: ' . $e->getMessage());
    }
}

function termApiCloseOrphanGameSessions(int $terminalId, ?int $gameId = null): void
{
    try {
        $db = getDB();
        $now = date('Y-m-d H:i:s');
        $params = [$now, $terminalId];
        $sql = 'UPDATE game_sessions
             SET ended_at = ?
             WHERE terminal_id = ?
               AND ended_at IS NULL
               AND credits_bet > 0
               AND started_at < DATE_SUB(NOW(), INTERVAL 15 MINUTE)';

        if ($gameId !== null && $gameId > 0) {
            $sql .= ' AND game_id = ?';
            $params[] = $gameId;
        }

        $db->query($sql, $params);
    } catch (Throwable $e) {
        error_log('termApiCloseOrphanGameSessions: ' . $e->getMessage());
    }
}

function termApiCloseIdleGameSessions(int $terminalId): void
{
    try {
        $db = getDB();
        $now = date('Y-m-d H:i:s');

        $db->query(
            'UPDATE game_sessions
             SET ended_at = ?
             WHERE terminal_id = ?
               AND ended_at IS NULL
               AND credits_bet = 0',
            [$now, $terminalId]
        );

        $db->query(
            'UPDATE game_sessions
             SET ended_at = ?
             WHERE terminal_id = ?
               AND ended_at IS NULL
               AND credits_bet > 0
               AND started_at < DATE_SUB(NOW(), INTERVAL 15 MINUTE)',
            [$now, $terminalId]
        );

        $db->query(
            'UPDATE game_sessions
             SET ended_at = ?
             WHERE terminal_id = ?
               AND ended_at IS NULL
               AND started_at < DATE_SUB(NOW(), INTERVAL 6 HOUR)',
            [$now, $terminalId]
        );
    } catch (Throwable $e) {
        error_log('termApiCloseIdleGameSessions: ' . $e->getMessage());
    }
}

function termApiTerminalHasOpenGame(int $terminalId): bool
{
    try {
        $row = getDB()->fetchOne(
            'SELECT id FROM game_sessions
             WHERE terminal_id = ?
               AND ended_at IS NULL
               AND credits_bet > 0
             LIMIT 1',
            [$terminalId]
        );

        return !empty($row);
    } catch (Throwable $e) {
        error_log('termApiTerminalHasOpenGame: ' . $e->getMessage());
        return false;
    }
}

function termApiParseBetPerLine($raw): float
{
    return round(max(0, (float) $raw), 2);
}

function termApiNormalizeCredits($value): float
{
    return round(max(0, (float) $value), 2);
}

function termApiSessionDepositCredits(array $terminal): float
{
    $ceiling = termApiSessionCeiling($terminal);

    return $ceiling['credits'];
}

function termApiSessionCeiling(array $terminal): array
{
    $empty = ['credits' => 0.0, 'lei' => 0.0];
    $terminalId = (int) ($terminal['id'] ?? 0);
    if ($terminalId <= 0 || !function_exists('termPlayVisitFindOpen')) {
        return $empty;
    }

    $visit = termPlayVisitFindOpen($terminalId);
    if (!is_array($visit)) {
        return $empty;
    }

    $rate = termTerminalCreditRate($terminal);
    if ($rate <= 0) {
        $rate = 0.1;
    }

    $moneyIn = round((float) ($visit['money_in'] ?? 0), 2);
    $startedAt = (string) ($visit['started_at'] ?? '');
    $ledgerMoney = 0.0;
    $ledgerCredits = 0.0;
    $startCredits = 0.0;

    if ($startedAt !== '') {
        try {
            $rows = getDB()->fetchAll(
                'SELECT amount_credits, amount_money, balance_after
                 FROM terminal_transactions
                 WHERE terminal_id = ? AND type = ? AND created_at >= ?
                 ORDER BY id ASC',
                [$terminalId, 'money_in', $startedAt]
            );
        } catch (Throwable $e) {
            error_log('termApiSessionCeiling: ' . $e->getMessage());
            $rows = [];
        }

        if (is_array($rows) && $rows !== []) {
            $firstAfter = round((float) ($rows[0]['balance_after'] ?? 0), 2);
            $laterCredits = 0.0;
            foreach ($rows as $index => $row) {
                $ledgerMoney += (float) ($row['amount_money'] ?? 0);
                $ledgerCredits += (float) ($row['amount_credits'] ?? 0);
                if ($index > 0) {
                    $laterCredits += (float) ($row['amount_credits'] ?? 0);
                }
            }
            $ledgerMoney = round($ledgerMoney, 2);
            $ledgerCredits = round($ledgerCredits, 2);
            $startCredits = round($firstAfter + $laterCredits, 2);
        }
    }

    if ($moneyIn <= 0) {
        $moneyIn = $ledgerMoney;
    }
    if ($moneyIn <= 0 && $ledgerCredits <= 0 && $startCredits <= 0) {
        return $empty;
    }

    $fromMoney = $moneyIn > 0 ? round($moneyIn / $rate, 2) : 0.0;
    $credits = max($fromMoney, $ledgerCredits, $startCredits);
    $lei = max($moneyIn, round($credits * $rate, 2));
    if ($lei > 0) {
        $credits = max($credits, round($lei / $rate, 2));
    }

    return [
        'credits' => termApiNormalizeCredits($credits),
        'lei' => round(max(0, $lei), 2),
    ];
}

function termApiCapSpinWinCredits(array $terminal, float $creditsWon, ?float $balanceCredits = null): float
{
    $creditsWon = termApiNormalizeCredits($creditsWon);
    if ($creditsWon <= 0) {
        return 0.0;
    }

    $ceiling = termApiSessionCeiling($terminal);
    if ($ceiling['credits'] <= 0 && $ceiling['lei'] <= 0) {
        return $creditsWon;
    }

    $rate = termTerminalCreditRate($terminal);
    if ($rate <= 0) {
        $rate = 0.1;
    }

    if ($balanceCredits === null) {
        $balanceCredits = termApiFetchCreditsBalanceById((int) ($terminal['id'] ?? 0));
    }
    $balanceCredits = termApiNormalizeCredits($balanceCredits);

    $roomCredits = $ceiling['credits'] - $balanceCredits;
    $balanceLei = round($balanceCredits * $rate, 2);
    $roomLei = round($ceiling['lei'] - $balanceLei, 2);
    $roomFromLei = $roomLei > 0 ? round($roomLei / $rate, 2) : 0.0;
    $room = max($roomCredits, $roomFromLei);
    if ($room <= 0.009) {
        return 0.0;
    }

    $room = termApiNormalizeCredits($room);
    if ($creditsWon <= $room + 0.001) {
        return $creditsWon;
    }

    return $room;
}

function termApiMaxTerminalLei(): float
{
    return 1000.0;
}

function termApiMaxWithdrawalLei(): float
{
    return 1000.0;
}

function termApiWithdrawOptionsRon(): array
{
    return [10, 50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
}

function termApiCreditsForWithdrawRon(array $terminal, float $amountRon): int
{
    $rate = termTerminalCreditRate($terminal);
    if ($rate <= 0) {
        $rate = 0.1;
    }

    return (int) floor($amountRon / $rate);
}

function termApiValidateMoneyOutCredits(array $terminal, int $creditsOut): ?string
{
    if ($creditsOut <= 0) {
        return 'Suma invalida.';
    }

    $rate = termTerminalCreditRate($terminal);
    if ($rate <= 0) {
        $rate = 0.1;
    }

    $grossLei = round($creditsOut * $rate, 2);
    if ($grossLei > termApiMaxWithdrawalLei() + 0.01) {
        return 'Maxim ' . number_format(termApiMaxWithdrawalLei(), 0, ',', '.') . ' Puncte per retragere.';
    }

    $valid = false;
    foreach (termApiWithdrawOptionsRon() as $optionRon) {
        if (termApiCreditsForWithdrawRon($terminal, (float) $optionRon) === $creditsOut) {
            $valid = true;
            break;
        }
    }

    if (!$valid) {
        return 'Alege una dintre sumele fixe disponibile (10–1000 Puncte).';
    }

    return null;
}

function termApiMaxCreditsForTerminal(array $terminal): float
{
    $rate = termTerminalCreditRate($terminal);

    return (float) floor(termApiMaxTerminalLei() / $rate);
}

function termApiMaxCreditsBalance(): float
{
    $rate = max(0.0001, termAdminCreditRateValue(termSetting('default_credit_rate', '0.1')));

    return (float) floor(termApiMaxTerminalLei() / $rate);
}

function termApiClampCreditsToCap($value, array $terminal): float
{
    return min(termApiMaxCreditsForTerminal($terminal), termApiNormalizeCredits($value));
}

function termApiClampCreditsBalance($value): float
{
    return min(termApiMaxCreditsBalance(), termApiNormalizeCredits($value));
}

function termApiCreditsBalance(array $terminal): float
{
    return termApiNormalizeCredits($terminal['credits_balance'] ?? 0);
}

function termApiFetchCreditsBalanceById(int $terminalId): float
{
    $row = getDB()->fetchOne(
        'SELECT credits_balance FROM terminals WHERE id = ? LIMIT 1',
        [$terminalId]
    );

    return termApiNormalizeCredits($row['credits_balance'] ?? 0);
}

function termApiBalanceCapPayload(array $terminal): array
{
    $balance = termApiCreditsBalance($terminal);
    $maxCredits = termApiMaxCreditsForTerminal($terminal);
    $over = $balance > $maxCredits + 0.001;
    $minWithdrawCredits = $over ? (float) ceil($balance - $maxCredits) : 0.0;

    return [
        'max_terminal_lei' => termApiMaxTerminalLei(),
        'max_credits' => $maxCredits,
        'balance_over_cap' => $over,
        'min_withdraw_credits' => $minWithdrawCredits,
        'min_withdraw_ron' => round($minWithdrawCredits * termTerminalCreditRate($terminal), 2),
        'max_withdrawal_lei' => termApiMaxWithdrawalLei(),
        'withdraw_options_ron' => termApiWithdrawOptionsRon(),
    ];
}

function termApiRequireBalanceUnderCap(array $terminal): void
{
    $cap = termApiBalanceCapPayload($terminal);
    if (!$cap['balance_over_cap']) {
        return;
    }

    termJson([
        'ok' => false,
        'message' => 'Disponibilul depaseste plafonul de '
            . number_format(termApiMaxTerminalLei(), 0, ',', '.')
            . ' Puncte. Retrage o suma pentru a continua.',
        'code' => 'forced_withdraw',
        'balance_cap' => $cap,
        'credits_balance' => termApiCreditsBalance($terminal),
    ], 423);
}

function termApiAdjustCreditsBalance(int $terminalId, float $delta): float
{
    $db = getDB();
    $pdo = $db->getConnection();
    $delta = round((float) $delta, 2);

    if ($delta === 0.0) {
        return termApiFetchCreditsBalanceById($terminalId);
    }

    $pdo->beginTransaction();
    try {
        $row = $db->fetchOne(
            'SELECT credits_balance FROM terminals WHERE id = ? LIMIT 1 FOR UPDATE',
            [$terminalId]
        );

        if (!$row) {
            throw new RuntimeException('Terminal negasit.');
        }

        $newBalance = termApiNormalizeCredits((float) ($row['credits_balance'] ?? 0) + $delta);
        if ($newBalance < 0) {
            throw new RuntimeException('Disponibil insuficient.');
        }

        $db->update('terminals', [
            'credits_balance' => $newBalance,
        ], 'id = :id', ['id' => $terminalId]);

        $pdo->commit();

        return $newBalance;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }
}

function termApiStoreBetPerLine(float $betPerLine): int
{
    return max(0, (int) round($betPerLine * 100));
}

function termApiBetPerLineFromStored(int $stored): float
{
    if ($stored <= 0) {
        return 0.0;
    }

    return round($stored / 100, 2);
}

function termApiTotalBetCredits(float $betPerLine, int $lines): float
{
    $lineHundredths = termApiStoreBetPerLine($betPerLine);
    $totalHundredths = $lineHundredths * max(1, $lines);

    return termApiNormalizeCredits($totalHundredths / 100);
}

function termApiMinTotalBetCredits(): float
{
    return 5.0;
}

function termApiMaxTotalBetCredits(): float
{
    return 20.0;
}

function termApiCalculateWithdrawalPayout(float $grossMoneyRon): array
{
    $gross = round(max(0, $grossMoneyRon), 2);

    return [
        'gross_money' => $gross,
        'taxable_money' => 0.0,
        'tax_money' => 0.0,
        'net_money' => $gross,
    ];
}

function termApiCreditsEqual(float $left, float $right): bool
{
    return abs(termApiNormalizeCredits($left) - termApiNormalizeCredits($right)) < 0.001;
}

function termApiEnsureStackerColumns(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        $exists = getDB()->fetchOne("SHOW COLUMNS FROM terminals LIKE 'stacker_bills'");
        if ($exists) {
            return;
        }

        getDB()->query(
            'ALTER TABLE terminals
             ADD COLUMN stacker_capacity INT UNSIGNED NOT NULL DEFAULT 1000 AFTER credit_rate,
             ADD COLUMN stacker_bills INT UNSIGNED NOT NULL DEFAULT 0 AFTER stacker_capacity,
             ADD COLUMN stacker_alert_pct TINYINT UNSIGNED NOT NULL DEFAULT 80 AFTER stacker_bills,
             ADD COLUMN stacker_last_reset_at DATETIME NULL AFTER stacker_alert_pct'
        );
    } catch (Throwable $e) {
        error_log('termApiEnsureStackerColumns: ' . $e->getMessage());
    }
}

function termApiStackerCapacity(array $terminal): int
{
    $capacity = (int) ($terminal['stacker_capacity'] ?? 1000);
    return $capacity > 0 ? $capacity : 1000;
}

function termApiStackerBills(array $terminal): int
{
    return max(0, (int) ($terminal['stacker_bills'] ?? 0));
}

function termApiStackerAlertPct(array $terminal): int
{
    $pct = (int) ($terminal['stacker_alert_pct'] ?? 80);
    if ($pct < 1) {
        $pct = 80;
    }
    if ($pct > 100) {
        $pct = 100;
    }
    return $pct;
}

function termApiStackerPayload(array $terminal): array
{
    termApiEnsureStackerColumns();

    $capacity = termApiStackerCapacity($terminal);
    $bills = termApiStackerBills($terminal);
    if ($bills > $capacity) {
        $bills = $capacity;
    }
    $alertPct = termApiStackerAlertPct($terminal);
    $pct = $capacity > 0 ? (int) floor(($bills * 100) / $capacity) : 0;

    return [
        'stacker_bills' => $bills,
        'stacker_capacity' => $capacity,
        'stacker_pct' => $pct,
        'stacker_alert_pct' => $alertPct,
        'stacker_alert' => $pct >= $alertPct,
        'stacker_full' => $bills >= $capacity,
        'stacker_last_reset_at' => $terminal['stacker_last_reset_at'] ?? null,
    ];
}

function termApiFetchStackerTerminal(int $terminalId): array
{
    termApiEnsureStackerColumns();
    $row = getDB()->fetchOne(
        'SELECT id, stacker_bills, stacker_capacity, stacker_alert_pct, stacker_last_reset_at
         FROM terminals WHERE id = ? LIMIT 1',
        [$terminalId]
    );
    return is_array($row) ? $row : ['id' => $terminalId];
}

function termApiIncrementStackerBills(int $terminalId): array
{
    termApiEnsureStackerColumns();
    $db = getDB();
    $row = $db->fetchOne(
        'SELECT stacker_bills, stacker_capacity, stacker_alert_pct, stacker_last_reset_at
         FROM terminals WHERE id = ? LIMIT 1',
        [$terminalId]
    );
    if (!$row) {
        return termApiStackerPayload(['id' => $terminalId]);
    }

    $capacity = termApiStackerCapacity($row);
    $bills = min($capacity, termApiStackerBills($row) + 1);
    $db->update('terminals', [
        'stacker_bills' => $bills,
    ], 'id = :id', ['id' => $terminalId]);

    $row['stacker_bills'] = $bills;
    return termApiStackerPayload($row);
}

function termApiResetStackerBills(int $terminalId, string $notes = 'stacker_reset'): array
{
    termApiEnsureStackerColumns();
    $db = getDB();
    $fresh = termApiFetchStackerTerminal($terminalId);
    $now = date('Y-m-d H:i:s');
    $balance = termApiFetchCreditsBalanceById($terminalId);

    $db->update('terminals', [
        'stacker_bills' => 0,
        'stacker_last_reset_at' => $now,
    ], 'id = :id', ['id' => $terminalId]);

    $db->insert('terminal_transactions', [
        'terminal_id' => $terminalId,
        'type' => 'reset',
        'amount_credits' => 0,
        'amount_money' => 0,
        'balance_after' => $balance,
        'notes' => $notes !== '' ? $notes : 'stacker_reset',
    ]);

    $fresh['stacker_bills'] = 0;
    $fresh['stacker_last_reset_at'] = $now;
    return termApiStackerPayload($fresh);
}

function termApiVerifyLocationStaffPin(array $terminal, string $pin): array
{
    $pin = trim($pin);
    if ($pin === '') {
        return ['ok' => false, 'message' => 'Introdu PIN-ul angajatului locatiei.'];
    }

    $terminalId = (int) ($terminal['id'] ?? 0);
    $stationId = (int) ($terminal['station_id'] ?? 0);
    $shopIds = [];

    try {
        if ($stationId > 0) {
            $station = getDB()->fetchOne(
                'SELECT operator_id FROM stations WHERE id = ? LIMIT 1',
                [$stationId]
            );
            $operatorId = (int) ($station['operator_id'] ?? 0);
            if ($operatorId > 0) {
                $shopIds[] = $operatorId;
            }
        }
        if ($terminalId > 0) {
            $assigned = getDB()->fetchAll(
                "SELECT user_id FROM terminal_assignments
                 WHERE terminal_id = ? AND assignment_role = 'statie'",
                [$terminalId]
            );
            foreach ($assigned as $row) {
                $userId = (int) ($row['user_id'] ?? 0);
                if ($userId > 0) {
                    $shopIds[] = $userId;
                }
            }
        }
    } catch (Throwable $e) {
        return ['ok' => false, 'message' => 'PIN invalid.'];
    }

    $shopIds = array_values(array_unique($shopIds));
    if ($shopIds === []) {
        return ['ok' => false, 'message' => 'Locatia nu are angajat configurat.'];
    }

    $placeholders = implode(',', array_fill(0, count($shopIds), '?'));
    try {
        $staff = getDB()->fetchAll(
            "SELECT id, username, password_hash, display_name, role, is_active, created_by
             FROM users
             WHERE is_active = 1
               AND (
                    (id IN ({$placeholders}) AND role = 'statie')
                    OR (role = 'casier' AND created_by IN ({$placeholders}))
               )",
            array_merge($shopIds, $shopIds)
        );
    } catch (Throwable $e) {
        return ['ok' => false, 'message' => 'PIN invalid.'];
    }

    $matched = null;
    foreach ($staff as $user) {
        $hash = trim((string) ($user['password_hash'] ?? ''));
        if ($hash === '') {
            continue;
        }
        if (password_verify($pin, $hash)) {
            $matched = $user;
        }
    }

    if ($matched === null) {
        return ['ok' => false, 'message' => 'PIN invalid.'];
    }

    $accessible = termAccessibleTerminalIds($matched);
    if (!in_array($terminalId, $accessible, true)) {
        return ['ok' => false, 'message' => 'PIN invalid.'];
    }

    return [
        'ok' => true,
        'user' => [
            'id' => (int) $matched['id'],
            'username' => (string) ($matched['username'] ?? ''),
            'role' => (string) ($matched['role'] ?? ''),
        ],
    ];
}
